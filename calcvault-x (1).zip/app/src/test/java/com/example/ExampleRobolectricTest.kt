package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.calculator.AngleMode
import com.example.calculator.EvaluationResult
import com.example.calculator.ScientificCalculatorEngine
import com.example.security.PinVerificationResult
import com.example.security.SecurityPreferences
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("CalcVault X", appName)
  }

  @Test
  fun `test scientific calculator engine basic and trig`() {
    val engine = ScientificCalculatorEngine()
    engine.angleMode = AngleMode.DEG

    // 2 + 3 * 4 = 14
    val res1 = engine.evaluate("2+3*4")
    assertTrue(res1 is EvaluationResult.Success)
    assertEquals("14", (res1 as EvaluationResult.Success).displayString)

    // sin(30) in degrees = 0.5
    val res2 = engine.evaluate("sin(30)")
    assertTrue(res2 is EvaluationResult.Success)
    assertEquals("0.5", (res2 as EvaluationResult.Success).displayString)

    // 5! = 120
    val res3 = engine.evaluate("5!")
    assertTrue(res3 is EvaluationResult.Success)
    assertEquals("120", (res3 as EvaluationResult.Success).displayString)
  }

  @Test
  fun `test security preferences and pin verification`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val securityPrefs = SecurityPreferences(context)

    securityPrefs.setupPin("7788")
    assertTrue(securityPrefs.isPinConfigured())

    val correctResult = securityPrefs.verifyPin("7788")
    assertTrue(correctResult is PinVerificationResult.Success)
    assertTrue(securityPrefs.isVaultUnlocked.value)

    securityPrefs.lockVault()
    val wrongResult = securityPrefs.verifyPin("1111")
    assertTrue(wrongResult is PinVerificationResult.Failed)
  }
}
