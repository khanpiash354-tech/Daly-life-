package com.example.security

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.security.KeyStore
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.CipherInputStream
import javax.crypto.CipherOutputStream
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

object VaultCrypto {
  private const val ANDROID_KEYSTORE = "AndroidKeyStore"
  private const val MASTER_KEY_ALIAS = "CalcVaultX_MasterKey_v1"
  private const val AES_GCM_NO_PADDING = "AES/GCM/NoPadding"
  private const val GCM_IV_LENGTH = 12
  private const val GCM_TAG_LENGTH = 128

  private fun getOrCreateMasterKey(): SecretKey {
    val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
    if (keyStore.containsAlias(MASTER_KEY_ALIAS)) {
      val entry = keyStore.getEntry(MASTER_KEY_ALIAS, null) as? KeyStore.SecretKeyEntry
      if (entry != null) return entry.secretKey
    }

    val keyGenerator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
    val keyGenSpec = KeyGenParameterSpec.Builder(
      MASTER_KEY_ALIAS,
      KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
    )
      .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
      .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
      .setKeySize(256)
      .setRandomizedEncryptionRequired(true)
      .build()

    keyGenerator.init(keyGenSpec)
    return keyGenerator.generateKey()
  }

  /**
   * Encrypts an input stream to an encrypted target file using AES/GCM.
   * Prepends the 12-byte IV to the output file.
   */
  fun encryptStreamToFile(inputStream: InputStream, destinationFile: File): Long {
    val secretKey = getOrCreateMasterKey()
    val cipher = Cipher.getInstance(AES_GCM_NO_PADDING)
    cipher.init(Cipher.ENCRYPT_MODE, secretKey)
    val iv = cipher.iv

    destinationFile.parentFile?.mkdirs()
    FileOutputStream(destinationFile).use { fos ->
      fos.write(iv)
      CipherOutputStream(fos, cipher).use { cos ->
        inputStream.copyTo(cos)
      }
    }
    return destinationFile.length()
  }

  /**
   * Decrypts an encrypted file to an output stream using AES/GCM.
   * Reads the first 12 bytes as the IV.
   */
  fun decryptFileToStream(encryptedFile: File, outputStream: OutputStream) {
    FileInputStream(encryptedFile).use { fis ->
      val iv = ByteArray(GCM_IV_LENGTH)
      val readIv = fis.read(iv)
      if (readIv != GCM_IV_LENGTH) {
        throw IllegalArgumentException("Invalid encrypted file format or corrupted header")
      }
      val secretKey = getOrCreateMasterKey()
      val cipher = Cipher.getInstance(AES_GCM_NO_PADDING)
      val spec = GCMParameterSpec(GCM_TAG_LENGTH, iv)
      cipher.init(Cipher.DECRYPT_MODE, secretKey, spec)

      CipherInputStream(fis, cipher).use { cis ->
        cis.copyTo(outputStream)
      }
    }
  }

  /**
   * Decrypts file bytes into memory (for images, small pdfs, notes, or thumbnails).
   */
  fun decryptFileToBytes(encryptedFile: File): ByteArray {
    FileInputStream(encryptedFile).use { fis ->
      val iv = ByteArray(GCM_IV_LENGTH)
      val readIv = fis.read(iv)
      if (readIv != GCM_IV_LENGTH) {
        throw IllegalArgumentException("Invalid encrypted file format")
      }
      val secretKey = getOrCreateMasterKey()
      val cipher = Cipher.getInstance(AES_GCM_NO_PADDING)
      val spec = GCMParameterSpec(GCM_TAG_LENGTH, iv)
      cipher.init(Cipher.DECRYPT_MODE, secretKey, spec)

      CipherInputStream(fis, cipher).use { cis ->
        return cis.readBytes()
      }
    }
  }

  /**
   * Hashes a PIN with a salt using SHA-256.
   */
  fun hashPin(pin: String, salt: String): String {
    val md = MessageDigest.getInstance("SHA-256")
    val combined = "$salt:$pin:$salt"
    val digest = md.digest(combined.toByteArray(Charsets.UTF_8))
    return digest.joinToString("") { "%02x".format(it) }
  }

  fun generateSalt(): String {
    val random = SecureRandom()
    val bytes = ByteArray(16)
    random.nextBytes(bytes)
    return bytes.joinToString("") { "%02x".format(it) }
  }
}
