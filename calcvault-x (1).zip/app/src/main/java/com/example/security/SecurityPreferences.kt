package com.example.security

import android.content.Context
import android.content.SharedPreferences
import com.example.ui.theme.AppThemeMode
import com.example.ui.theme.LcdThemeMode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class AutoLockOption(val title: String, val timeoutMillis: Long) {
  IMMEDIATE("Immediately", 0L),
  AFTER_1_MIN("After 1 minute", 60_000L),
  AFTER_5_MIN("After 5 minutes", 300_000L),
  NEVER("Never (Session only)", -1L)
}

class SecurityPreferences(context: Context) {
  private val prefs: SharedPreferences =
    context.getSharedPreferences("calcvaultx_secure_prefs", Context.MODE_PRIVATE)

  private val _isVaultUnlocked = MutableStateFlow(false)
  val isVaultUnlocked: StateFlow<Boolean> = _isVaultUnlocked.asStateFlow()

  private val _isDecoyMode = MutableStateFlow(false)
  val isDecoyMode: StateFlow<Boolean> = _isDecoyMode.asStateFlow()

  var lastBackgroundedTime: Long = 0L

  fun isPinConfigured(): Boolean {
    return prefs.getString(KEY_PIN_HASH, null) != null
  }

  fun setupPin(newPin: String) {
    val salt = VaultCrypto.generateSalt()
    val hash = VaultCrypto.hashPin(newPin, salt)
    prefs.edit()
      .putString(KEY_PIN_SALT, salt)
      .putString(KEY_PIN_HASH, hash)
      .apply()
  }

  fun setupDecoyPin(decoyPin: String?) {
    if (decoyPin.isNullOrBlank()) {
      prefs.edit().remove(KEY_DECOY_SALT).remove(KEY_DECOY_HASH).apply()
    } else {
      val salt = VaultCrypto.generateSalt()
      val hash = VaultCrypto.hashPin(decoyPin, salt)
      prefs.edit()
        .putString(KEY_DECOY_SALT, salt)
        .putString(KEY_DECOY_HASH, hash)
        .apply()
    }
  }

  fun hasDecoyPin(): Boolean {
    return prefs.getString(KEY_DECOY_HASH, null) != null
  }

  fun verifyPin(inputPin: String): PinVerificationResult {
    // Check lockout first
    val lockoutUntil = prefs.getLong(KEY_LOCKOUT_UNTIL, 0L)
    val now = System.currentTimeMillis()
    if (lockoutUntil > now) {
      val remainingSeconds = ((lockoutUntil - now) / 1000).toInt() + 1
      return PinVerificationResult.LockedOut(remainingSeconds)
    }

    // Check decoy PIN if configured
    val decoySalt = prefs.getString(KEY_DECOY_SALT, null)
    val decoyHash = prefs.getString(KEY_DECOY_HASH, null)
    if (decoySalt != null && decoyHash != null) {
      val inputDecoyHash = VaultCrypto.hashPin(inputPin, decoySalt)
      if (inputDecoyHash == decoyHash) {
        resetFailedAttempts()
        _isDecoyMode.value = true
        _isVaultUnlocked.value = true
        return PinVerificationResult.Success(isDecoy = true)
      }
    }

    // Check real PIN
    val realSalt = prefs.getString(KEY_PIN_SALT, null)
    val realHash = prefs.getString(KEY_PIN_HASH, null)
    if (realSalt == null || realHash == null) {
      return PinVerificationResult.NotConfigured
    }

    val inputHash = VaultCrypto.hashPin(inputPin, realSalt)
    if (inputHash == realHash) {
      resetFailedAttempts()
      _isDecoyMode.value = false
      _isVaultUnlocked.value = true
      return PinVerificationResult.Success(isDecoy = false)
    } else {
      val failed = prefs.getInt(KEY_FAILED_ATTEMPTS, 0) + 1
      if (failed >= MAX_FAILED_ATTEMPTS) {
        val lockDuration = 30_000L // 30 seconds
        prefs.edit()
          .putInt(KEY_FAILED_ATTEMPTS, 0)
          .putLong(KEY_LOCKOUT_UNTIL, now + lockDuration)
          .apply()
        return PinVerificationResult.LockedOut(30)
      } else {
        prefs.edit().putInt(KEY_FAILED_ATTEMPTS, failed).apply()
        return PinVerificationResult.Failed(attemptsRemaining = MAX_FAILED_ATTEMPTS - failed)
      }
    }
  }

  fun unlockWithBiometrics() {
    resetFailedAttempts()
    _isDecoyMode.value = false
    _isVaultUnlocked.value = true
  }

  fun lockVault() {
    _isVaultUnlocked.value = false
    _isDecoyMode.value = false
  }

  fun checkAutoLockOnForeground() {
    if (!_isVaultUnlocked.value) return
    val autoLock = getAutoLockOption()
    if (autoLock.timeoutMillis < 0L) return // Never lock
    val now = System.currentTimeMillis()
    if (lastBackgroundedTime > 0 && (now - lastBackgroundedTime) >= autoLock.timeoutMillis) {
      lockVault()
    }
  }

  private fun resetFailedAttempts() {
    prefs.edit()
      .putInt(KEY_FAILED_ATTEMPTS, 0)
      .putLong(KEY_LOCKOUT_UNTIL, 0L)
      .apply()
  }

  fun isBiometricEnabled(): Boolean {
    return prefs.getBoolean(KEY_BIOMETRIC_ENABLED, false)
  }

  fun setBiometricEnabled(enabled: Boolean) {
    prefs.edit().putBoolean(KEY_BIOMETRIC_ENABLED, enabled).apply()
  }

  fun getAutoLockOption(): AutoLockOption {
    val name = prefs.getString(KEY_AUTO_LOCK, AutoLockOption.IMMEDIATE.name)
    return try {
      AutoLockOption.valueOf(name ?: AutoLockOption.IMMEDIATE.name)
    } catch (_: Exception) {
      AutoLockOption.IMMEDIATE
    }
  }

  fun setAutoLockOption(option: AutoLockOption) {
    prefs.edit().putString(KEY_AUTO_LOCK, option.name).apply()
  }

  fun getAppTheme(): AppThemeMode {
    val name = prefs.getString(KEY_APP_THEME, AppThemeMode.DARK_NAVY.name)
    return try {
      AppThemeMode.valueOf(name ?: AppThemeMode.DARK_NAVY.name)
    } catch (_: Exception) {
      AppThemeMode.DARK_NAVY
    }
  }

  fun setAppTheme(theme: AppThemeMode) {
    prefs.edit().putString(KEY_APP_THEME, theme.name).apply()
  }

  fun getLcdTheme(): LcdThemeMode {
    val name = prefs.getString(KEY_LCD_THEME, LcdThemeMode.CLASSIC_GREEN.name)
    return try {
      LcdThemeMode.valueOf(name ?: LcdThemeMode.CLASSIC_GREEN.name)
    } catch (_: Exception) {
      LcdThemeMode.CLASSIC_GREEN
    }
  }

  fun setLcdTheme(theme: LcdThemeMode) {
    prefs.edit().putString(KEY_LCD_THEME, theme.name).apply()
  }

  companion object {
    private const val KEY_PIN_SALT = "pin_salt"
    private const val KEY_PIN_HASH = "pin_hash"
    private const val KEY_DECOY_SALT = "decoy_salt"
    private const val KEY_DECOY_HASH = "decoy_hash"
    private const val KEY_FAILED_ATTEMPTS = "failed_attempts"
    private const val KEY_LOCKOUT_UNTIL = "lockout_until"
    private const val KEY_BIOMETRIC_ENABLED = "biometric_enabled"
    private const val KEY_AUTO_LOCK = "auto_lock"
    private const val KEY_APP_THEME = "app_theme"
    private const val KEY_LCD_THEME = "lcd_theme"

    const val MAX_FAILED_ATTEMPTS = 5
  }
}

sealed class PinVerificationResult {
  data class Success(val isDecoy: Boolean) : PinVerificationResult()
  data class Failed(val attemptsRemaining: Int) : PinVerificationResult()
  data class LockedOut(val remainingSeconds: Int) : PinVerificationResult()
  object NotConfigured : PinVerificationResult()
}
