package com.example.vault

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import androidx.core.content.FileProvider
import com.example.data.AppDatabase
import com.example.data.model.VaultFileEntity
import com.example.data.model.VaultFileType
import com.example.security.VaultCrypto
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

class MediaVaultManager(private val context: Context) {
  private val vaultDao = AppDatabase.getDatabase(context).vaultFileDao()
  private val vaultDir = File(context.filesDir, "vault_files").apply { mkdirs() }
  private val cacheDir = File(context.cacheDir, "decrypted_preview").apply { mkdirs() }

  suspend fun importFileFromUri(uri: Uri, isDecoy: Boolean = false): VaultFileEntity? =
    withContext(Dispatchers.IO) {
      val contentResolver = context.contentResolver
      var displayName = "file_${System.currentTimeMillis()}"
      var sizeBytes = 0L

      contentResolver.query(uri, null, null, null, null)?.use { cursor ->
        val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
        if (cursor.moveToFirst()) {
          if (nameIndex != -1) displayName = cursor.getString(nameIndex) ?: displayName
          if (sizeIndex != -1) sizeBytes = cursor.getLong(sizeIndex)
        }
      }

      val mimeType = contentResolver.getType(uri) ?: getMimeTypeFromExtension(displayName)
      val fileType = determineFileType(mimeType, displayName)
      val storedFileName = "${UUID.randomUUID()}.vault"
      val destinationFile = File(vaultDir, storedFileName)

      val encryptedLength = try {
        contentResolver.openInputStream(uri)?.use { inputStream ->
          VaultCrypto.encryptStreamToFile(inputStream, destinationFile)
        } ?: return@withContext null
      } catch (e: Exception) {
        e.printStackTrace()
        destinationFile.delete()
        return@withContext null
      }

      val entity = VaultFileEntity(
        originalName = displayName,
        storedFileName = storedFileName,
        fileType = fileType,
        mimeType = mimeType,
        fileSizeBytes = if (sizeBytes > 0) sizeBytes else encryptedLength,
        isDecoy = isDecoy
      )

      val id = vaultDao.insertFile(entity)
      entity.copy(id = id)
    }

  suspend fun decryptFileForPreview(fileEntity: VaultFileEntity): File =
    withContext(Dispatchers.IO) {
      val encryptedFile = File(vaultDir, fileEntity.storedFileName)
      val safeExtension = fileEntity.originalName.substringAfterLast('.', "")
      val extSuffix = if (safeExtension.isNotBlank()) ".$safeExtension" else ""
      val tempDecryptedFile = File(cacheDir, "preview_${fileEntity.id}$extSuffix")

      FileOutputStream(tempDecryptedFile).use { fos ->
        VaultCrypto.decryptFileToStream(encryptedFile, fos)
      }
      tempDecryptedFile
    }

  suspend fun loadDecryptedImageBitmap(fileEntity: VaultFileEntity): Bitmap? =
    withContext(Dispatchers.IO) {
      if (fileEntity.fileType != VaultFileType.PHOTO) return@withContext null
      try {
        val encryptedFile = File(vaultDir, fileEntity.storedFileName)
        val bytes = VaultCrypto.decryptFileToBytes(encryptedFile)
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
      } catch (e: Exception) {
        e.printStackTrace()
        null
      }
    }

  suspend fun deleteFile(fileEntity: VaultFileEntity) = withContext(Dispatchers.IO) {
    val encryptedFile = File(vaultDir, fileEntity.storedFileName)
    if (encryptedFile.exists()) encryptedFile.delete()
    vaultDao.deleteFile(fileEntity)
  }

  suspend fun exportFile(fileEntity: VaultFileEntity) = withContext(Dispatchers.IO) {
    val tempFile = decryptFileForPreview(fileEntity)
    val shareUri = try {
      FileProvider.getUriForFile(
        context,
        "${context.packageName}.fileprovider",
        tempFile
      )
    } catch (_: Exception) {
      Uri.fromFile(tempFile)
    }

    val shareIntent = Intent(Intent.ACTION_SEND).apply {
      type = fileEntity.mimeType
      putExtra(Intent.EXTRA_STREAM, shareUri)
      putExtra(Intent.EXTRA_TITLE, fileEntity.originalName)
      addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
    }
    context.startActivity(Intent.createChooser(shareIntent, "Export or Share ${fileEntity.originalName}").apply {
      addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    })
  }

  private fun determineFileType(mimeType: String, name: String): VaultFileType {
    val lowerMime = mimeType.lowercase()
    val lowerName = name.lowercase()
    return when {
      lowerMime.startsWith("image/") || lowerName.endsWith(".jpg") || lowerName.endsWith(".jpeg") || lowerName.endsWith(".png") || lowerName.endsWith(".webp") -> VaultFileType.PHOTO
      lowerMime.startsWith("video/") || lowerName.endsWith(".mp4") || lowerName.endsWith(".mkv") || lowerName.endsWith(".mov") -> VaultFileType.VIDEO
      lowerMime.contains("pdf") || lowerName.endsWith(".pdf") || lowerName.endsWith(".doc") || lowerName.endsWith(".docx") || lowerName.endsWith(".txt") -> VaultFileType.DOCUMENT
      lowerMime.startsWith("audio/") || lowerName.endsWith(".mp3") || lowerName.endsWith(".wav") || lowerName.endsWith(".m4a") -> VaultFileType.AUDIO
      else -> VaultFileType.OTHER
    }
  }

  private fun getMimeTypeFromExtension(name: String): String {
    val ext = name.substringAfterLast('.', "").lowercase()
    return when (ext) {
      "jpg", "jpeg" -> "image/jpeg"
      "png" -> "image/png"
      "webp" -> "image/webp"
      "mp4" -> "video/mp4"
      "pdf" -> "application/pdf"
      "txt" -> "text/plain"
      "doc", "docx" -> "application/msword"
      else -> "application/octet-stream"
    }
  }
}
