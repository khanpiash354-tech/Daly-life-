package com.example

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.biometric.BiometricPrompt
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import com.example.security.SecurityPreferences
import com.example.ui.calculator.CalculatorScreen
import com.example.ui.launcher.PublicLauncherScreen
import com.example.ui.theme.AppThemeMode
import com.example.ui.theme.CalcVaultTheme
import com.example.ui.vault.VaultDashboardScreen

enum class MainAppScreen {
  CALCULATOR,
  VAULT_DASHBOARD,
  PUBLIC_LAUNCHER
}

class MainActivity : FragmentActivity() {
  private lateinit var securityPreferences: SecurityPreferences

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    securityPreferences = SecurityPreferences(this)

    setContent {
      var currentTheme by remember { mutableStateOf(securityPreferences.getAppTheme()) }
      val isVaultUnlocked by securityPreferences.isVaultUnlocked.collectAsState()
      val isDecoyMode by securityPreferences.isDecoyMode.collectAsState()
      var appScreen by remember { mutableStateOf(MainAppScreen.CALCULATOR) }

      LaunchedEffect(isVaultUnlocked) {
        if (isVaultUnlocked) {
          appScreen = MainAppScreen.VAULT_DASHBOARD
        } else if (appScreen == MainAppScreen.VAULT_DASHBOARD) {
          appScreen = MainAppScreen.CALCULATOR
        }
      }

      CalcVaultTheme(themeMode = currentTheme) {
        Surface(modifier = Modifier.fillMaxSize()) {
          Crossfade(targetState = appScreen, label = "screen_transition") { screen ->
            when (screen) {
              MainAppScreen.CALCULATOR -> {
                CalculatorScreen(
                  securityPreferences = securityPreferences,
                  onUnlockVault = {
                    appScreen = MainAppScreen.VAULT_DASHBOARD
                  },
                  onOpenLauncher = {
                    appScreen = MainAppScreen.PUBLIC_LAUNCHER
                  },
                  onOpenBiometric = {
                    showBiometricPrompt()
                  }
                )
              }
              MainAppScreen.VAULT_DASHBOARD -> {
                VaultDashboardScreen(
                  securityPreferences = securityPreferences,
                  isDecoyMode = isDecoyMode,
                  onLockVault = {
                    securityPreferences.lockVault()
                    appScreen = MainAppScreen.CALCULATOR
                  },
                  onThemeChanged = { newTheme ->
                    currentTheme = newTheme
                  }
                )
              }
              MainAppScreen.PUBLIC_LAUNCHER -> {
                PublicLauncherScreen(
                  onReturnToCalculator = {
                    appScreen = MainAppScreen.CALCULATOR
                  }
                )
              }
            }
          }
        }
      }
    }
  }

  private fun showBiometricPrompt() {
    val executor = ContextCompat.getMainExecutor(this)
    val biometricPrompt = BiometricPrompt(this, executor, object : BiometricPrompt.AuthenticationCallback() {
      override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
        super.onAuthenticationSucceeded(result)
        securityPreferences.unlockWithBiometrics()
      }

      override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
        super.onAuthenticationError(errorCode, errString)
        // User canceled or failed
      }
    })

    val promptInfo = BiometricPrompt.PromptInfo.Builder()
      .setTitle("Unlock CalcVault X")
      .setSubtitle("Confirm your fingerprint or biometric credential")
      .setNegativeButtonText("Use Calculator PIN")
      .build()

    biometricPrompt.authenticate(promptInfo)
  }

  override fun onPause() {
    super.onPause()
    securityPreferences.lastBackgroundedTime = System.currentTimeMillis()
  }

  override fun onResume() {
    super.onResume()
    securityPreferences.checkAutoLockOnForeground()
  }
}
