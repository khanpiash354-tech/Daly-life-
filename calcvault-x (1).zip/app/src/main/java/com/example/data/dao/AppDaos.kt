package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.CalcHistoryEntity
import com.example.data.model.HiddenAppEntity
import com.example.data.model.NoteEntity
import com.example.data.model.VaultFileEntity
import com.example.data.model.VaultFileType
import kotlinx.coroutines.flow.Flow

@Dao
interface NoteDao {
  @Query("SELECT * FROM notes WHERE isDecoy = :isDecoy ORDER BY isPinned DESC, updatedAt DESC")
  fun getAllNotes(isDecoy: Boolean): Flow<List<NoteEntity>>

  @Query("SELECT * FROM notes WHERE isDecoy = :isDecoy AND (title LIKE '%' || :query || '%' OR content LIKE '%' || :query || '%') ORDER BY isPinned DESC, updatedAt DESC")
  fun searchNotes(query: String, isDecoy: Boolean): Flow<List<NoteEntity>>

  @Query("SELECT * FROM notes WHERE isDecoy = :isDecoy AND folder = :folder ORDER BY isPinned DESC, updatedAt DESC")
  fun getNotesByFolder(folder: String, isDecoy: Boolean): Flow<List<NoteEntity>>

  @Query("SELECT DISTINCT folder FROM notes WHERE isDecoy = :isDecoy")
  fun getAllFolders(isDecoy: Boolean): Flow<List<String>>

  @Query("SELECT * FROM notes WHERE id = :id LIMIT 1")
  suspend fun getNoteById(id: Long): NoteEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertNote(note: NoteEntity): Long

  @Update
  suspend fun updateNote(note: NoteEntity)

  @Delete
  suspend fun deleteNote(note: NoteEntity)
}

@Dao
interface VaultFileDao {
  @Query("SELECT * FROM vault_files WHERE isDecoy = :isDecoy ORDER BY dateAdded DESC")
  fun getAllFiles(isDecoy: Boolean): Flow<List<VaultFileEntity>>

  @Query("SELECT * FROM vault_files WHERE isDecoy = :isDecoy AND fileType = :type ORDER BY dateAdded DESC")
  fun getFilesByType(type: VaultFileType, isDecoy: Boolean): Flow<List<VaultFileEntity>>

  @Query("SELECT * FROM vault_files WHERE isDecoy = :isDecoy AND originalName LIKE '%' || :query || '%' ORDER BY dateAdded DESC")
  fun searchFiles(query: String, isDecoy: Boolean): Flow<List<VaultFileEntity>>

  @Query("SELECT * FROM vault_files WHERE id = :id LIMIT 1")
  suspend fun getFileById(id: Long): VaultFileEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertFile(file: VaultFileEntity): Long

  @Delete
  suspend fun deleteFile(file: VaultFileEntity)
}

@Dao
interface HiddenAppDao {
  @Query("SELECT * FROM hidden_apps ORDER BY appName ASC")
  fun getAllHiddenApps(): Flow<List<HiddenAppEntity>>

  @Query("SELECT * FROM hidden_apps")
  suspend fun getAllHiddenAppsSync(): List<HiddenAppEntity>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertHiddenApp(hiddenApp: HiddenAppEntity)

  @Delete
  suspend fun deleteHiddenApp(hiddenApp: HiddenAppEntity)

  @Query("DELETE FROM hidden_apps WHERE packageName = :packageName AND activityName = :activityName")
  suspend fun unhideApp(packageName: String, activityName: String)

  @Query("SELECT EXISTS(SELECT 1 FROM hidden_apps WHERE packageName = :packageName AND activityName = :activityName)")
  suspend fun isAppHidden(packageName: String, activityName: String): Boolean
}

@Dao
interface CalcHistoryDao {
  @Query("SELECT * FROM calc_history ORDER BY timestamp DESC LIMIT 100")
  fun getHistory(): Flow<List<CalcHistoryEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertHistory(entry: CalcHistoryEntity)

  @Query("DELETE FROM calc_history")
  suspend fun clearHistory()
}
