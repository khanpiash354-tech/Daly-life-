package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import com.example.data.dao.CalcHistoryDao
import com.example.data.dao.HiddenAppDao
import com.example.data.dao.NoteDao
import com.example.data.dao.VaultFileDao
import com.example.data.model.CalcHistoryEntity
import com.example.data.model.HiddenAppEntity
import com.example.data.model.NoteEntity
import com.example.data.model.VaultFileEntity
import com.example.data.model.VaultFileType

class Converters {
  @TypeConverter
  fun fromVaultFileType(value: VaultFileType): String = value.name

  @TypeConverter
  fun toVaultFileType(value: String): VaultFileType =
    try {
      VaultFileType.valueOf(value)
    } catch (_: Exception) {
      VaultFileType.OTHER
    }
}

@Database(
  entities = [
    NoteEntity::class,
    VaultFileEntity::class,
    HiddenAppEntity::class,
    CalcHistoryEntity::class
  ],
  version = 1,
  exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
  abstract fun noteDao(): NoteDao
  abstract fun vaultFileDao(): VaultFileDao
  abstract fun hiddenAppDao(): HiddenAppDao
  abstract fun calcHistoryDao(): CalcHistoryDao

  companion object {
    @Volatile
    private var INSTANCE: AppDatabase? = null

    fun getDatabase(context: Context): AppDatabase {
      return INSTANCE ?: synchronized(this) {
        val instance = Room.databaseBuilder(
          context.applicationContext,
          AppDatabase::class.java,
          "calcvaultx_db"
        )
          .fallbackToDestructiveMigration()
          .build()
        INSTANCE = instance
        instance
      }
    }
  }
}
