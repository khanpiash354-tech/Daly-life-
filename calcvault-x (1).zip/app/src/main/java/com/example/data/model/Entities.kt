package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "notes")
data class NoteEntity(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0,
  val title: String,
  val content: String,
  val folder: String = "General",
  val isPrivate: Boolean = false,
  val isChecklist: Boolean = false,
  val checklistItemsJson: String = "",
  val colorHex: String = "#0D172E",
  val isPinned: Boolean = false,
  val isDecoy: Boolean = false,
  val createdAt: Long = System.currentTimeMillis(),
  val updatedAt: Long = System.currentTimeMillis()
)

enum class VaultFileType {
  PHOTO,
  VIDEO,
  DOCUMENT,
  AUDIO,
  OTHER
}

@Entity(tableName = "vault_files")
data class VaultFileEntity(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0,
  val originalName: String,
  val storedFileName: String,
  val fileType: VaultFileType,
  val mimeType: String,
  val fileSizeBytes: Long,
  val dateAdded: Long = System.currentTimeMillis(),
  val isDecoy: Boolean = false
)

@Entity(tableName = "hidden_apps", primaryKeys = ["packageName", "activityName"])
data class HiddenAppEntity(
  val packageName: String,
  val activityName: String,
  val appName: String,
  val dateHidden: Long = System.currentTimeMillis()
)

@Entity(tableName = "calc_history")
data class CalcHistoryEntity(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0,
  val expression: String,
  val result: String,
  val timestamp: Long = System.currentTimeMillis()
)
