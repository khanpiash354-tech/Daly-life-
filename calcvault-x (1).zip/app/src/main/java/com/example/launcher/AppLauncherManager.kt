package com.example.launcher

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import com.example.data.AppDatabase
import com.example.data.model.HiddenAppEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class InstalledApp(
  val packageName: String,
  val activityName: String,
  val label: String,
  val icon: Drawable?,
  val isHidden: Boolean = false
)

class AppLauncherManager(private val context: Context) {
  private val packageManager: PackageManager = context.packageManager
  private val hiddenAppDao = AppDatabase.getDatabase(context).hiddenAppDao()

  suspend fun getInstalledApps(includeHidden: Boolean = true): List<InstalledApp> =
    withContext(Dispatchers.IO) {
      val intent = Intent(Intent.ACTION_MAIN, null).apply {
        addCategory(Intent.CATEGORY_LAUNCHER)
      }
      val resolveInfos = packageManager.queryIntentActivities(intent, 0)
      val hiddenApps = hiddenAppDao.getAllHiddenAppsSync().associateBy { "${it.packageName}/${it.activityName}" }

      val list = mutableListOf<InstalledApp>()
      for (info in resolveInfos) {
        val pkg = info.activityInfo.packageName
        // Do not list CalcVault X itself in the hidden apps picker to avoid confusion
        if (pkg == context.packageName) continue

        val activity = info.activityInfo.name
        val key = "$pkg/$activity"
        val isHidden = hiddenApps.containsKey(key)

        if (!includeHidden && isHidden) continue

        val label = info.loadLabel(packageManager).toString()
        val icon = try {
          info.loadIcon(packageManager)
        } catch (_: Exception) {
          null
        }

        list.add(
          InstalledApp(
            packageName = pkg,
            activityName = activity,
            label = label,
            icon = icon,
            isHidden = isHidden
          )
        )
      }

      list.sortedBy { it.label.lowercase() }
    }

  suspend fun hideApp(app: InstalledApp) = withContext(Dispatchers.IO) {
    hiddenAppDao.insertHiddenApp(
      HiddenAppEntity(
        packageName = app.packageName,
        activityName = app.activityName,
        appName = app.label
      )
    )
  }

  suspend fun unhideApp(packageName: String, activityName: String) = withContext(Dispatchers.IO) {
    hiddenAppDao.unhideApp(packageName, activityName)
  }

  fun launchApp(packageName: String): Boolean {
    return try {
      val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
      if (launchIntent != null) {
        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(launchIntent)
        true
      } else {
        false
      }
    } catch (_: Exception) {
      false
    }
  }
}
