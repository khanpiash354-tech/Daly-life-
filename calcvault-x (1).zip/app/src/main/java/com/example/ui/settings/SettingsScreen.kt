package com.example.ui.settings

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.security.AutoLockOption
import com.example.security.PinVerificationResult
import com.example.security.SecurityPreferences
import com.example.ui.theme.AppThemeMode
import com.example.ui.theme.LcdThemeMode

@Composable
fun SettingsScreen(
  securityPreferences: SecurityPreferences,
  onThemeChanged: (AppThemeMode) -> Unit
) {
  var showChangePinDialog by remember { mutableStateOf(false) }
  var showDecoyPinDialog by remember { mutableStateOf(false) }
  var showAutoLockDialog by remember { mutableStateOf(false) }
  var showThemeDialog by remember { mutableStateOf(false) }
  var showLcdThemeDialog by remember { mutableStateOf(false) }

  var isBiometricEnabled by remember { mutableStateOf(securityPreferences.isBiometricEnabled()) }
  var currentAutoLock by remember { mutableStateOf(securityPreferences.getAutoLockOption()) }
  var currentAppTheme by remember { mutableStateOf(securityPreferences.getAppTheme()) }
  var currentLcdTheme by remember { mutableStateOf(securityPreferences.getLcdTheme()) }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp)
      .verticalScroll(rememberScrollState())
      .testTag("settings_screen")
  ) {
    Text(
      "Security & Authentication",
      fontWeight = FontWeight.Bold,
      fontSize = 15.sp,
      color = MaterialTheme.colorScheme.primary
    )

    Spacer(modifier = Modifier.height(8.dp))

    // 1. Change PIN
    SettingsItem(
      title = "Change 4-Digit PIN",
      subtitle = "Update the master PIN used to unlock your vault",
      icon = Icons.Default.Password,
      onClick = { showChangePinDialog = true }
    )

    // 2. Decoy / Panic PIN
    SettingsItem(
      title = "Decoy Fake PIN (Panic Mode)",
      subtitle = if (securityPreferences.hasDecoyPin()) "Active • Opens empty decoy vault" else "Not set • Creates plausible deniability",
      icon = Icons.Default.Masks,
      onClick = { showDecoyPinDialog = true }
    )

    // 3. Biometric Unlock
    Card(
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
      shape = RoundedCornerShape(12.dp),
      modifier = Modifier
        .fillMaxWidth()
        .padding(vertical = 4.dp)
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
          Icon(Icons.Default.Fingerprint, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
          Spacer(modifier = Modifier.width(12.dp))
          Column {
            Text("Fingerprint / Face Unlock", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Text("Unlock directly using Android Biometrics", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          }
        }
        Switch(
          checked = isBiometricEnabled,
          onCheckedChange = { checked ->
            isBiometricEnabled = checked
            securityPreferences.setBiometricEnabled(checked)
          }
        )
      }
    }

    // 4. Auto-lock timeout
    SettingsItem(
      title = "Auto-Lock Timer",
      subtitle = currentAutoLock.title,
      icon = Icons.Default.LockClock,
      onClick = { showAutoLockDialog = true }
    )

    Spacer(modifier = Modifier.height(20.dp))

    Text(
      "Customization & Appearance",
      fontWeight = FontWeight.Bold,
      fontSize = 15.sp,
      color = MaterialTheme.colorScheme.primary
    )

    Spacer(modifier = Modifier.height(8.dp))

    // 5. App Theme
    SettingsItem(
      title = "App Color Theme",
      subtitle = currentAppTheme.title,
      icon = Icons.Default.Palette,
      onClick = { showThemeDialog = true }
    )

    // 6. Calculator LCD Theme
    SettingsItem(
      title = "Calculator LCD Style",
      subtitle = currentLcdTheme.title,
      icon = Icons.Default.Calculate,
      onClick = { showLcdThemeDialog = true }
    )

    Spacer(modifier = Modifier.height(20.dp))

    Text(
      "Privacy & Offline Assurance",
      fontWeight = FontWeight.Bold,
      fontSize = 15.sp,
      color = MaterialTheme.colorScheme.primary
    )

    Spacer(modifier = Modifier.height(8.dp))

    Card(
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
      shape = RoundedCornerShape(12.dp),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Default.CloudOff, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
          Spacer(modifier = Modifier.width(8.dp))
          Text("100% Offline & Private", fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
          "CalcVault X never connects to the internet or sends your private data anywhere. All files, notes, and cryptographic keys remain strictly on this device.",
          fontSize = 12.sp,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }
    }
  }

  // Change PIN Dialog
  if (showChangePinDialog) {
    ChangePinDialog(
      securityPreferences = securityPreferences,
      onDismiss = { showChangePinDialog = false }
    )
  }

  // Decoy PIN Dialog
  if (showDecoyPinDialog) {
    DecoyPinDialog(
      securityPreferences = securityPreferences,
      onDismiss = { showDecoyPinDialog = false }
    )
  }

  // Auto Lock Selector Dialog
  if (showAutoLockDialog) {
    AlertDialog(
      onDismissRequest = { showAutoLockDialog = false },
      title = { Text("Auto-Lock Timeout") },
      text = {
        Column {
          AutoLockOption.values().forEach { option ->
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .clickable {
                  currentAutoLock = option
                  securityPreferences.setAutoLockOption(option)
                  showAutoLockDialog = false
                }
                .padding(vertical = 10.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              RadioButton(
                selected = currentAutoLock == option,
                onClick = {
                  currentAutoLock = option
                  securityPreferences.setAutoLockOption(option)
                  showAutoLockDialog = false
                }
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text(option.title)
            }
          }
        }
      },
      confirmButton = {
        TextButton(onClick = { showAutoLockDialog = false }) { Text("Cancel") }
      }
    )
  }

  // App Theme Dialog
  if (showThemeDialog) {
    AlertDialog(
      onDismissRequest = { showThemeDialog = false },
      title = { Text("Choose App Theme") },
      text = {
        Column {
          AppThemeMode.values().forEach { mode ->
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .clickable {
                  currentAppTheme = mode
                  securityPreferences.setAppTheme(mode)
                  onThemeChanged(mode)
                  showThemeDialog = false
                }
                .padding(vertical = 10.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              RadioButton(
                selected = currentAppTheme == mode,
                onClick = {
                  currentAppTheme = mode
                  securityPreferences.setAppTheme(mode)
                  onThemeChanged(mode)
                  showThemeDialog = false
                }
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text(mode.title)
            }
          }
        }
      },
      confirmButton = {
        TextButton(onClick = { showThemeDialog = false }) { Text("Cancel") }
      }
    )
  }

  // LCD Theme Dialog
  if (showLcdThemeDialog) {
    AlertDialog(
      onDismissRequest = { showLcdThemeDialog = false },
      title = { Text("Choose LCD Display Style") },
      text = {
        Column {
          LcdThemeMode.values().forEach { mode ->
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .clickable {
                  currentLcdTheme = mode
                  securityPreferences.setLcdTheme(mode)
                  showLcdThemeDialog = false
                }
                .padding(vertical = 10.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              RadioButton(
                selected = currentLcdTheme == mode,
                onClick = {
                  currentLcdTheme = mode
                  securityPreferences.setLcdTheme(mode)
                  showLcdThemeDialog = false
                }
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text(mode.title)
            }
          }
        }
      },
      confirmButton = {
        TextButton(onClick = { showLcdThemeDialog = false }) { Text("Cancel") }
      }
    )
  }
}

@Composable
fun SettingsItem(
  title: String,
  subtitle: String,
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  onClick: () -> Unit
) {
  Card(
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
    shape = RoundedCornerShape(12.dp),
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 4.dp)
      .clickable(onClick = onClick)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
      Spacer(modifier = Modifier.width(12.dp))
      Column(modifier = Modifier.weight(1f)) {
        Text(title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
        Text(subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
      }
      Icon(Icons.Default.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
    }
  }
}

@Composable
fun ChangePinDialog(
  securityPreferences: SecurityPreferences,
  onDismiss: () -> Unit
) {
  var oldPin by remember { mutableStateOf("") }
  var newPin by remember { mutableStateOf("") }
  var confirmPin by remember { mutableStateOf("") }
  var errorMessage by remember { mutableStateOf<String?>(null) }
  var successMessage by remember { mutableStateOf<String?>(null) }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("Change 4-Digit PIN") },
    text = {
      Column {
        OutlinedTextField(
          value = oldPin,
          onValueChange = { if (it.length <= 4 && it.all { c -> c.isDigit() }) oldPin = it },
          label = { Text("Current PIN") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(
          value = newPin,
          onValueChange = { if (it.length <= 4 && it.all { c -> c.isDigit() }) newPin = it },
          label = { Text("New 4-Digit PIN") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(
          value = confirmPin,
          onValueChange = { if (it.length <= 4 && it.all { c -> c.isDigit() }) confirmPin = it },
          label = { Text("Confirm New PIN") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth()
        )

        if (errorMessage != null) {
          Spacer(modifier = Modifier.height(8.dp))
          Text(errorMessage!!, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
        }
        if (successMessage != null) {
          Spacer(modifier = Modifier.height(8.dp))
          Text(successMessage!!, color = MaterialTheme.colorScheme.primary, fontSize = 12.sp)
        }
      }
    },
    confirmButton = {
      Button(
        onClick = {
          when (val res = securityPreferences.verifyPin(oldPin)) {
            is PinVerificationResult.Success -> {
              if (newPin.length != 4) {
                errorMessage = "New PIN must be 4 digits"
              } else if (newPin != confirmPin) {
                errorMessage = "New PINs do not match"
              } else {
                securityPreferences.setupPin(newPin)
                successMessage = "PIN successfully changed!"
                errorMessage = null
              }
            }
            else -> {
              errorMessage = "Current PIN is incorrect"
            }
          }
        }
      ) {
        Text("Update PIN")
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) { Text("Close") }
    }
  )
}

@Composable
fun DecoyPinDialog(
  securityPreferences: SecurityPreferences,
  onDismiss: () -> Unit
) {
  var decoyPin by remember { mutableStateOf("") }
  var confirmDecoyPin by remember { mutableStateOf("") }
  var errorMessage by remember { mutableStateOf<String?>(null) }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("Set Decoy Fake PIN") },
    text = {
      Column {
        Text(
          "If forced to open your vault under duress, entering this Decoy PIN on the calculator opens a completely empty, fake vault with zero traces of your real files.",
          fontSize = 12.sp,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
          value = decoyPin,
          onValueChange = { if (it.length <= 4 && it.all { c -> c.isDigit() }) decoyPin = it },
          label = { Text("Decoy 4-Digit PIN") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(
          value = confirmDecoyPin,
          onValueChange = { if (it.length <= 4 && it.all { c -> c.isDigit() }) confirmDecoyPin = it },
          label = { Text("Confirm Decoy PIN") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth()
        )

        if (errorMessage != null) {
          Spacer(modifier = Modifier.height(8.dp))
          Text(errorMessage!!, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
        }
      }
    },
    confirmButton = {
      Button(
        onClick = {
          if (decoyPin.isNotBlank()) {
            if (decoyPin.length != 4) {
              errorMessage = "Decoy PIN must be 4 digits"
            } else if (decoyPin != confirmDecoyPin) {
              errorMessage = "Decoy PINs do not match"
            } else {
              securityPreferences.setupDecoyPin(decoyPin)
              onDismiss()
            }
          } else {
            securityPreferences.setupDecoyPin(null)
            onDismiss()
          }
        }
      ) {
        Text("Save Decoy PIN")
      }
    },
    dismissButton = {
      if (securityPreferences.hasDecoyPin()) {
        TextButton(
          onClick = {
            securityPreferences.setupDecoyPin(null)
            onDismiss()
          }
        ) {
          Text("Remove Decoy", color = MaterialTheme.colorScheme.error)
        }
      } else {
        TextButton(onClick = onDismiss) { Text("Cancel") }
      }
    }
  )
}
