package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// CalcVault X Signature Palette - Dark Navy & Electric Blue
val ElectricBlue = Color(0xFF00E5FF)
val ElectricBlueDark = Color(0xFF00B0FF)
val DeepNavy = Color(0xFF060B19)
val SurfaceNavy = Color(0xFF0D172E)
val SurfaceNavyElevated = Color(0xFF142346)
val BorderNavy = Color(0xFF1E325C)
val CyanAccent = Color(0xFF00BFA5)
val AmberAccent = Color(0xFFFFB300)
val CoralAccent = Color(0xFFFF5252)

// Casio fx-100MS Hardware Colors
val CasioBodyDark = Color(0xFF181C24)
val CasioBodyTop = Color(0xFF222834)
val CasioKeyDark = Color(0xFF2C3240)
val CasioKeyNumber = Color(0xFF384050)
val CasioKeyFunction = Color(0xFF232A38)
val CasioKeyShift = Color(0xFFF59E0B)
val CasioKeyAlpha = Color(0xFFEF4444)
val CasioKeyDelAc = Color(0xFFDC2626)
val CasioKeyEquals = Color(0xFF0284C7)

// Scientific LCD Display Colors
val LcdBackgroundGreen = Color(0xFF8EB897)
val LcdTextGreen = Color(0xFF1B2E1D)
val LcdBackgroundBlue = Color(0xFF0F2642)
val LcdTextBlue = Color(0xFF64D2FF)
val LcdBackgroundAmber = Color(0xFF38290D)
val LcdTextAmber = Color(0xFFFFBE3B)
val LcdBackgroundWhite = Color(0xFF1A1D24)
val LcdTextWhite = Color(0xFFF1F5F9)

// Theme Variants
val PitchBlack = Color(0xFF000000)
val PitchBlackSurface = Color(0xFF121212)
val PitchBlackElevated = Color(0xFF1E1E1E)

val LightBackground = Color(0xFFF1F5F9)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceElevated = Color(0xFFE2E8F0)
