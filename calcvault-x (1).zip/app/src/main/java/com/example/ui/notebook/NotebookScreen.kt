package com.example.ui.notebook

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.dao.NoteDao
import com.example.data.model.NoteEntity
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotebookScreen(
  noteDao: NoteDao,
  isDecoyMode: Boolean = false
) {
  val coroutineScope = rememberCoroutineScope()
  var searchQuery by remember { mutableStateOf("") }
  var selectedFolder by remember { mutableStateOf("All") }
  var editingNote by remember { mutableStateOf<NoteEntity?>(null) }
  var isCreatingNew by remember { mutableStateOf(false) }

  val allNotes by noteDao.getAllNotes(isDecoy = isDecoyMode).collectAsState(initial = emptyList())
  val allFolders by noteDao.getAllFolders(isDecoy = isDecoyMode).collectAsState(initial = emptyList())

  val filteredNotes = remember(allNotes, searchQuery, selectedFolder) {
    allNotes.filter { note ->
      val matchesFolder = selectedFolder == "All" || note.folder.equals(selectedFolder, ignoreCase = true)
      val matchesQuery = searchQuery.isBlank() ||
        note.title.contains(searchQuery, ignoreCase = true) ||
        note.content.contains(searchQuery, ignoreCase = true)
      matchesFolder && matchesQuery
    }
  }

  Scaffold(
    floatingActionButton = {
      FloatingActionButton(
        onClick = { isCreatingNew = true },
        containerColor = MaterialTheme.colorScheme.primary,
        contentColor = MaterialTheme.colorScheme.onPrimary,
        modifier = Modifier.testTag("add_note_fab")
      ) {
        Icon(Icons.Default.Add, contentDescription = "Add New Note")
      }
    }
  ) { innerPadding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .padding(horizontal = 16.dp)
    ) {
      Spacer(modifier = Modifier.height(8.dp))

      // Search bar
      OutlinedTextField(
        value = searchQuery,
        onValueChange = { searchQuery = it },
        placeholder = { Text("Search notes or checklists...") },
        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
        trailingIcon = {
          if (searchQuery.isNotEmpty()) {
            IconButton(onClick = { searchQuery = "" }) {
              Icon(Icons.Default.Clear, contentDescription = "Clear search")
            }
          }
        },
        singleLine = true,
        shape = RoundedCornerShape(24.dp),
        modifier = Modifier
          .fillMaxWidth()
          .testTag("note_search_input")
      )

      Spacer(modifier = Modifier.height(12.dp))

      // Folder filters row
      val folderList = listOf("All") + allFolders.filter { it.isNotBlank() && it != "All" }
      LazyRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        items(folderList) { folder ->
          FilterChip(
            selected = selectedFolder.equals(folder, ignoreCase = true),
            onClick = { selectedFolder = folder },
            label = { Text(folder) },
            leadingIcon = if (folder != "All") {
              { Icon(Icons.Default.Folder, contentDescription = null, modifier = Modifier.size(16.dp)) }
            } else null
          )
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Notes List
      if (filteredNotes.isEmpty()) {
        Box(
          contentAlignment = Alignment.Center,
          modifier = Modifier
            .fillMaxWidth()
            .weight(1f)
        ) {
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
              imageVector = Icons.Default.NoteAlt,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f),
              modifier = Modifier.size(64.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
              if (searchQuery.isNotBlank()) "No notes match '$searchQuery'" else "No notes in this folder",
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              fontSize = 15.sp
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              "Tap '+' below to create a secure note or checklist",
              color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
              fontSize = 12.sp
            )
          }
        }
      } else {
        LazyColumn(
          verticalArrangement = Arrangement.spacedBy(10.dp),
          modifier = Modifier
            .fillMaxWidth()
            .weight(1f)
            .testTag("notes_list")
        ) {
          items(filteredNotes, key = { it.id }) { note ->
            NoteCard(
              note = note,
              onClick = { editingNote = note },
              onPinToggle = {
                coroutineScope.launch {
                  noteDao.updateNote(note.copy(isPinned = !note.isPinned, updatedAt = System.currentTimeMillis()))
                }
              },
              onDelete = {
                coroutineScope.launch { noteDao.deleteNote(note) }
              }
            )
          }
          item { Spacer(modifier = Modifier.height(72.dp)) }
        }
      }
    }
  }

  // Note Editor Dialog
  if (isCreatingNew || editingNote != null) {
    val noteToEdit = editingNote ?: NoteEntity(
      title = "",
      content = "",
      folder = if (selectedFolder != "All") selectedFolder else "General",
      isDecoy = isDecoyMode
    )

    NoteEditorDialog(
      note = noteToEdit,
      isNew = isCreatingNew,
      onDismiss = {
        isCreatingNew = false
        editingNote = null
      },
      onSave = { updated ->
        coroutineScope.launch {
          if (isCreatingNew) {
            noteDao.insertNote(updated)
          } else {
            noteDao.updateNote(updated.copy(updatedAt = System.currentTimeMillis()))
          }
          isCreatingNew = false
          editingNote = null
        }
      }
    )
  }
}

@Composable
fun NoteCard(
  note: NoteEntity,
  onClick: () -> Unit,
  onPinToggle: () -> Unit,
  onDelete: () -> Unit
) {
  val dateFormat = remember { SimpleDateFormat("MMM d, yyyy • h:mm a", Locale.getDefault()) }

  Card(
    modifier = Modifier
      .fillMaxWidth()
      .clickable(onClick = onClick)
      .testTag("note_card_${note.id}"),
    colors = CardDefaults.cardColors(
      containerColor = MaterialTheme.colorScheme.surfaceVariant
    ),
    shape = RoundedCornerShape(12.dp)
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
          if (note.isPinned) {
            Icon(
              Icons.Default.PushPin,
              contentDescription = "Pinned",
              tint = MaterialTheme.colorScheme.primary,
              modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
          }
          Text(
            text = if (note.title.isNotBlank()) note.title else "Untitled Note",
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
          )
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
          Surface(
            shape = RoundedCornerShape(6.dp),
            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
          ) {
            Text(
              text = note.folder,
              fontSize = 11.sp,
              color = MaterialTheme.colorScheme.primary,
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )
          }
          Spacer(modifier = Modifier.width(4.dp))
          IconButton(onClick = onPinToggle, modifier = Modifier.size(28.dp)) {
            Icon(
              imageVector = if (note.isPinned) Icons.Default.PushPin else Icons.Default.OutlinedFlag,
              contentDescription = "Pin Note",
              tint = if (note.isPinned) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
              modifier = Modifier.size(18.dp)
            )
          }
          IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
            Icon(
              imageVector = Icons.Default.DeleteOutline,
              contentDescription = "Delete Note",
              tint = MaterialTheme.colorScheme.error,
              modifier = Modifier.size(18.dp)
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(6.dp))

      if (note.content.isNotBlank()) {
        Text(
          text = note.content,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          fontSize = 14.sp,
          maxLines = 3,
          overflow = TextOverflow.Ellipsis
        )
        Spacer(modifier = Modifier.height(8.dp))
      }

      Text(
        text = dateFormat.format(Date(note.updatedAt)),
        fontSize = 11.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
      )
    }
  }
}

@Composable
fun NoteEditorDialog(
  note: NoteEntity,
  isNew: Boolean,
  onDismiss: () -> Unit,
  onSave: (NoteEntity) -> Unit
) {
  var title by remember { mutableStateOf(note.title) }
  var content by remember { mutableStateOf(note.content) }
  var folder by remember { mutableStateOf(note.folder) }
  var isPinned by remember { mutableStateOf(note.isPinned) }
  var isPrivate by remember { mutableStateOf(note.isPrivate) }

  AlertDialog(
    onDismissRequest = onDismiss,
    modifier = Modifier.fillMaxWidth(0.95f),
    title = {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(if (isNew) "New Note" else "Edit Note", fontWeight = FontWeight.Bold)
        Row {
          IconButton(onClick = { isPinned = !isPinned }) {
            Icon(
              imageVector = if (isPinned) Icons.Default.PushPin else Icons.Default.OutlinedFlag,
              contentDescription = "Pin Note",
              tint = if (isPinned) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      }
    },
    text = {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .heightIn(max = 420.dp)
      ) {
        OutlinedTextField(
          value = title,
          onValueChange = { title = it },
          placeholder = { Text("Note Title") },
          singleLine = true,
          modifier = Modifier
            .fillMaxWidth()
            .testTag("note_title_input")
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
          value = folder,
          onValueChange = { folder = it },
          label = { Text("Folder (e.g. Work, Secrets, Ideas)") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
          value = content,
          onValueChange = { content = it },
          placeholder = { Text("Write your thoughts, passwords, or checklist...") },
          modifier = Modifier
            .fillMaxWidth()
            .height(200.dp)
            .testTag("note_content_input")
        )
      }
    },
    confirmButton = {
      Button(
        onClick = {
          onSave(
            note.copy(
              title = title.trim(),
              content = content.trim(),
              folder = if (folder.isBlank()) "General" else folder.trim(),
              isPinned = isPinned,
              isPrivate = isPrivate,
              updatedAt = System.currentTimeMillis()
            )
          )
        },
        modifier = Modifier.testTag("save_note_btn")
      ) {
        Text("Save")
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text("Cancel")
      }
    }
  )
}
