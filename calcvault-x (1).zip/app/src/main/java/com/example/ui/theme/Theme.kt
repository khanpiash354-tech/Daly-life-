package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

enum class AppThemeMode(val title: String) {
  DARK_NAVY("Dark Navy (Default)"),
  AMOLED_BLACK("AMOLED Pitch Black"),
  RETRO_CASIO("Retro Casio Gray"),
  LIGHT_MINIMAL("Clean Minimal Light")
}

enum class LcdThemeMode(val title: String, val bg: Color, val text: Color) {
  CLASSIC_GREEN("Classic Green Matrix", LcdBackgroundGreen, LcdTextGreen),
  CYBER_BLUE("Cyber Electric Blue", LcdBackgroundBlue, LcdTextBlue),
  AMBER_GLOW("Warm Amber Glow", LcdBackgroundAmber, LcdTextAmber),
  OLED_MONO("Modern High Contrast", LcdBackgroundWhite, LcdTextWhite)
}

private val DarkNavyColorScheme =
  darkColorScheme(
    primary = ElectricBlue,
    onPrimary = DeepNavy,
    primaryContainer = SurfaceNavyElevated,
    onPrimaryContainer = ElectricBlue,
    secondary = CyanAccent,
    onSecondary = DeepNavy,
    tertiary = AmberAccent,
    background = DeepNavy,
    onBackground = Color(0xFFECEFF4),
    surface = SurfaceNavy,
    onSurface = Color(0xFFECEFF4),
    surfaceVariant = SurfaceNavyElevated,
    onSurfaceVariant = Color(0xFF94A3B8),
    outline = BorderNavy
  )

private val AmoledColorScheme =
  darkColorScheme(
    primary = ElectricBlue,
    onPrimary = PitchBlack,
    primaryContainer = PitchBlackElevated,
    onPrimaryContainer = ElectricBlue,
    secondary = CyanAccent,
    onSecondary = PitchBlack,
    tertiary = AmberAccent,
    background = PitchBlack,
    onBackground = Color.White,
    surface = PitchBlackSurface,
    onSurface = Color.White,
    surfaceVariant = PitchBlackElevated,
    onSurfaceVariant = Color(0xFFA0AEC0),
    outline = Color(0xFF2D3748)
  )

private val RetroCasioColorScheme =
  darkColorScheme(
    primary = Color(0xFF60A5FA),
    onPrimary = Color(0xFF0F172A),
    primaryContainer = Color(0xFF334155),
    onPrimaryContainer = Color(0xFFE2E8F0),
    secondary = AmberAccent,
    onSecondary = Color(0xFF0F172A),
    tertiary = CoralAccent,
    background = CasioBodyDark,
    onBackground = Color(0xFFF8FAFC),
    surface = CasioBodyTop,
    onSurface = Color(0xFFF8FAFC),
    surfaceVariant = CasioKeyDark,
    onSurfaceVariant = Color(0xFFCBD5E1),
    outline = Color(0xFF475569)
  )

private val LightColorScheme =
  lightColorScheme(
    primary = Color(0xFF0284C7),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE0F2FE),
    onPrimaryContainer = Color(0xFF0369A1),
    secondary = Color(0xFF0D9488),
    onSecondary = Color.White,
    tertiary = Color(0xFFD97706),
    background = LightBackground,
    onBackground = Color(0xFF0F172A),
    surface = LightSurface,
    onSurface = Color(0xFF0F172A),
    surfaceVariant = LightSurfaceElevated,
    onSurfaceVariant = Color(0xFF475569),
    outline = Color(0xFFCBD5E1)
  )

@Composable
fun CalcVaultTheme(
  themeMode: AppThemeMode = AppThemeMode.DARK_NAVY,
  content: @Composable () -> Unit
) {
  val colorScheme =
    when (themeMode) {
      AppThemeMode.DARK_NAVY -> DarkNavyColorScheme
      AppThemeMode.AMOLED_BLACK -> AmoledColorScheme
      AppThemeMode.RETRO_CASIO -> RetroCasioColorScheme
      AppThemeMode.LIGHT_MINIMAL -> LightColorScheme
    }

  MaterialTheme(
    colorScheme = colorScheme,
    typography = Typography,
    content = content
  )
}
