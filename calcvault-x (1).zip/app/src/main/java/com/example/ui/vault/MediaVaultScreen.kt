package com.example.ui.vault

import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AppDatabase
import com.example.data.model.VaultFileEntity
import com.example.data.model.VaultFileType
import com.example.vault.MediaVaultManager
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MediaVaultScreen(isDecoyMode: Boolean = false) {
  val context = LocalContext.current
  val coroutineScope = rememberCoroutineScope()
  val db = remember { AppDatabase.getDatabase(context) }
  val vaultDao = db.vaultFileDao()
  val vaultManager = remember { MediaVaultManager(context) }

  var selectedType by remember { mutableStateOf<VaultFileType?>(null) }
  var searchQuery by remember { mutableStateOf("") }
  var isImporting by remember { mutableStateOf(false) }
  var viewingFile by remember { mutableStateOf<VaultFileEntity?>(null) }

  val filesList by vaultDao.getAllFiles(isDecoy = isDecoyMode).collectAsState(initial = emptyList())

  val filteredFiles = remember(filesList, selectedType, searchQuery) {
    filesList.filter { file ->
      val matchesType = selectedType == null || file.fileType == selectedType
      val matchesQuery = searchQuery.isBlank() || file.originalName.contains(searchQuery, ignoreCase = true)
      matchesType && matchesQuery
    }
  }

  // Photo / Video picker launcher
  val photoPickerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.PickMultipleVisualMedia()
  ) { uris: List<Uri> ->
    if (uris.isNotEmpty()) {
      isImporting = true
      coroutineScope.launch {
        for (uri in uris) {
          vaultManager.importFileFromUri(uri, isDecoy = isDecoyMode)
        }
        isImporting = false
      }
    }
  }

  // Documents / Any files picker launcher
  val documentPickerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.OpenMultipleDocuments()
  ) { uris: List<Uri> ->
    if (uris.isNotEmpty()) {
      isImporting = true
      coroutineScope.launch {
        for (uri in uris) {
          vaultManager.importFileFromUri(uri, isDecoy = isDecoyMode)
        }
        isImporting = false
      }
    }
  }

  var showImportMenu by remember { mutableStateOf(false) }

  Scaffold(
    floatingActionButton = {
      Box {
        FloatingActionButton(
          onClick = { showImportMenu = true },
          containerColor = MaterialTheme.colorScheme.primary,
          contentColor = MaterialTheme.colorScheme.onPrimary,
          modifier = Modifier.testTag("import_fab")
        ) {
          Icon(Icons.Default.Add, contentDescription = "Import Files to Vault")
        }

        DropdownMenu(
          expanded = showImportMenu,
          onDismissRequest = { showImportMenu = false }
        ) {
          DropdownMenuItem(
            text = { Text("Import Photos & Videos") },
            leadingIcon = { Icon(Icons.Default.PhotoLibrary, contentDescription = null) },
            onClick = {
              showImportMenu = false
              photoPickerLauncher.launch(
                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)
              )
            }
          )
          DropdownMenuItem(
            text = { Text("Import Documents & PDFs") },
            leadingIcon = { Icon(Icons.Default.Description, contentDescription = null) },
            onClick = {
              showImportMenu = false
              documentPickerLauncher.launch(arrayOf("*/*"))
            }
          )
        }
      }
    }
  ) { innerPadding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .padding(horizontal = 16.dp)
        .testTag("media_vault_screen")
    ) {
      Spacer(modifier = Modifier.height(8.dp))

      // Search bar
      OutlinedTextField(
        value = searchQuery,
        onValueChange = { searchQuery = it },
        placeholder = { Text("Search encrypted files...") },
        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
        trailingIcon = {
          if (searchQuery.isNotEmpty()) {
            IconButton(onClick = { searchQuery = "" }) {
              Icon(Icons.Default.Clear, contentDescription = "Clear")
            }
          }
        },
        singleLine = true,
        shape = RoundedCornerShape(24.dp),
        modifier = Modifier.fillMaxWidth()
      )

      Spacer(modifier = Modifier.height(10.dp))

      // Category filter chips
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        FilterChip(
          selected = selectedType == null,
          onClick = { selectedType = null },
          label = { Text("All (${filesList.size})") }
        )
        FilterChip(
          selected = selectedType == VaultFileType.PHOTO,
          onClick = { selectedType = VaultFileType.PHOTO },
          label = { Text("Photos") },
          leadingIcon = { Icon(Icons.Default.Image, contentDescription = null, modifier = Modifier.size(16.dp)) }
        )
        FilterChip(
          selected = selectedType == VaultFileType.VIDEO,
          onClick = { selectedType = VaultFileType.VIDEO },
          label = { Text("Videos") },
          leadingIcon = { Icon(Icons.Default.Videocam, contentDescription = null, modifier = Modifier.size(16.dp)) }
        )
        FilterChip(
          selected = selectedType == VaultFileType.DOCUMENT,
          onClick = { selectedType = VaultFileType.DOCUMENT },
          label = { Text("Docs/PDF") },
          leadingIcon = { Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp)) }
        )
      }

      Spacer(modifier = Modifier.height(12.dp))

      if (isImporting) {
        Card(
          modifier = Modifier.fillMaxWidth(),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
        ) {
          Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            CircularProgressIndicator(modifier = Modifier.size(24.dp), strokeWidth = 2.dp)
            Spacer(modifier = Modifier.width(12.dp))
            Text("Encrypting and securing files into hardware vault...", fontSize = 13.sp)
          }
        }
        Spacer(modifier = Modifier.height(12.dp))
      }

      if (filteredFiles.isEmpty()) {
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .weight(1f),
          contentAlignment = Alignment.Center
        ) {
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
              imageVector = Icons.Default.LockClock,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f),
              modifier = Modifier.size(64.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
              "No files in this vault category",
              fontSize = 16.sp,
              fontWeight = FontWeight.SemiBold,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              "Import personal photos, videos, or PDFs using '+'",
              fontSize = 12.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
            )
          }
        }
      } else {
        LazyVerticalGrid(
          columns = GridCells.Fixed(2),
          horizontalArrangement = Arrangement.spacedBy(10.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp),
          modifier = Modifier
            .fillMaxWidth()
            .weight(1f)
            .testTag("vault_grid")
        ) {
          items(filteredFiles, key = { it.id }) { file ->
            VaultFileCard(
              file = file,
              vaultManager = vaultManager,
              onClick = { viewingFile = file }
            )
          }
          item { Spacer(modifier = Modifier.height(72.dp)) }
        }
      }
    }
  }

  // File detail / Viewer Dialog
  if (viewingFile != null) {
    FileViewerDialog(
      file = viewingFile!!,
      vaultManager = vaultManager,
      onDismiss = { viewingFile = null },
      onDelete = {
        coroutineScope.launch {
          vaultManager.deleteFile(viewingFile!!)
          viewingFile = null
        }
      },
      onExport = {
        coroutineScope.launch {
          vaultManager.exportFile(viewingFile!!)
        }
      }
    )
  }
}

@Composable
fun VaultFileCard(
  file: VaultFileEntity,
  vaultManager: MediaVaultManager,
  onClick: () -> Unit
) {
  var bitmap by remember { mutableStateOf<Bitmap?>(null) }

  LaunchedEffect(file.id) {
    if (file.fileType == VaultFileType.PHOTO) {
      bitmap = vaultManager.loadDecryptedImageBitmap(file)
    }
  }

  Card(
    modifier = Modifier
      .fillMaxWidth()
      .height(150.dp)
      .clickable(onClick = onClick)
      .testTag("file_card_${file.id}"),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
    shape = RoundedCornerShape(12.dp)
  ) {
    Column(modifier = Modifier.fillMaxSize()) {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .weight(1f)
          .background(MaterialTheme.colorScheme.surface),
        contentAlignment = Alignment.Center
      ) {
        if (bitmap != null) {
          Image(
            bitmap = bitmap!!.asImageBitmap(),
            contentDescription = file.originalName,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
          )
        } else {
          Icon(
            imageVector = when (file.fileType) {
              VaultFileType.PHOTO -> Icons.Default.Image
              VaultFileType.VIDEO -> Icons.Default.Videocam
              VaultFileType.DOCUMENT -> Icons.Default.Description
              VaultFileType.AUDIO -> Icons.Default.Audiotrack
              VaultFileType.OTHER -> Icons.Default.InsertDriveFile
            },
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(36.dp)
          )
        }
      }

      Column(modifier = Modifier.padding(8.dp)) {
        Text(
          text = file.originalName,
          fontSize = 12.sp,
          fontWeight = FontWeight.Medium,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )
        Text(
          text = formatFileSize(file.fileSizeBytes),
          fontSize = 10.sp,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }
    }
  }
}

@Composable
fun FileViewerDialog(
  file: VaultFileEntity,
  vaultManager: MediaVaultManager,
  onDismiss: () -> Unit,
  onDelete: () -> Unit,
  onExport: () -> Unit
) {
  var fullImageBitmap by remember { mutableStateOf<Bitmap?>(null) }
  val dateFormat = remember { SimpleDateFormat("MMM d, yyyy • h:mm a", Locale.getDefault()) }

  LaunchedEffect(file.id) {
    if (file.fileType == VaultFileType.PHOTO) {
      fullImageBitmap = vaultManager.loadDecryptedImageBitmap(file)
    }
  }

  AlertDialog(
    onDismissRequest = onDismiss,
    modifier = Modifier.fillMaxWidth(0.95f),
    title = {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = file.originalName,
          fontSize = 16.sp,
          fontWeight = FontWeight.Bold,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
          modifier = Modifier.weight(1f)
        )
      }
    },
    text = {
      Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        if (fullImageBitmap != null) {
          Image(
            bitmap = fullImageBitmap!!.asImageBitmap(),
            contentDescription = file.originalName,
            modifier = Modifier
              .fillMaxWidth()
              .heightIn(max = 280.dp)
              .clip(RoundedCornerShape(8.dp)),
            contentScale = ContentScale.Fit
          )
          Spacer(modifier = Modifier.height(12.dp))
        } else {
          Icon(
            imageVector = when (file.fileType) {
              VaultFileType.PHOTO -> Icons.Default.Image
              VaultFileType.VIDEO -> Icons.Default.Videocam
              VaultFileType.DOCUMENT -> Icons.Default.Description
              VaultFileType.AUDIO -> Icons.Default.Audiotrack
              VaultFileType.OTHER -> Icons.Default.InsertDriveFile
            },
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(64.dp)
          )
          Spacer(modifier = Modifier.height(12.dp))
        }

        Text("Size: ${formatFileSize(file.fileSizeBytes)}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text("Imported: ${dateFormat.format(Date(file.dateAdded))}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text("Security: AES-GCM 256-Bit Hardware Encrypted", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
      }
    },
    confirmButton = {
      Row {
        IconButton(onClick = onExport) {
          Icon(Icons.Default.Share, contentDescription = "Export / Share File", tint = MaterialTheme.colorScheme.primary)
        }
        IconButton(onClick = onDelete) {
          Icon(Icons.Default.Delete, contentDescription = "Delete File", tint = MaterialTheme.colorScheme.error)
        }
        TextButton(onClick = onDismiss) {
          Text("Close")
        }
      }
    }
  )
}

fun formatFileSize(bytes: Long): String {
  if (bytes <= 0) return "0 B"
  val kb = bytes / 1024.0
  val mb = kb / 1024.0
  val gb = mb / 1024.0
  return when {
    gb >= 1.0 -> String.format(Locale.US, "%.1f GB", gb)
    mb >= 1.0 -> String.format(Locale.US, "%.1f MB", mb)
    kb >= 1.0 -> String.format(Locale.US, "%.1f KB", kb)
    else -> "$bytes B"
  }
}
