package com.example.ui.calculator

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.calculator.AngleMode
import com.example.calculator.EvaluationResult
import com.example.calculator.ScientificCalculatorEngine
import com.example.data.AppDatabase
import com.example.data.model.CalcHistoryEntity
import com.example.security.PinVerificationResult
import com.example.security.SecurityPreferences
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CalculatorScreen(
  securityPreferences: SecurityPreferences,
  onUnlockVault: () -> Unit,
  onOpenLauncher: () -> Unit,
  onOpenBiometric: () -> Unit
) {
  val context = LocalContext.current
  val coroutineScope = rememberCoroutineScope()
  val db = remember { AppDatabase.getDatabase(context) }
  val historyDao = db.calcHistoryDao()
  val historyList by historyDao.getHistory().collectAsState(initial = emptyList())

  val engine = remember { ScientificCalculatorEngine() }
  var expression by remember { mutableStateOf("") }
  var resultText by remember { mutableStateOf("0") }
  var shiftActive by remember { mutableStateOf(false) }
  var alphaActive by remember { mutableStateOf(false) }
  var angleMode by remember { mutableStateOf(AngleMode.DEG) }
  var isFractionMode by remember { mutableStateOf(false) }
  var rawResultValue by remember { mutableStateOf(0.0) }
  var statusMessage by remember { mutableStateOf<String?>(null) }
  var showHistorySheet by remember { mutableStateOf(false) }
  var showPinSetupDialog by remember { mutableStateOf(!securityPreferences.isPinConfigured()) }

  val lcdTheme = securityPreferences.getLcdTheme()

  fun vibrate() {
    try {
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
        vm?.defaultVibrator?.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK))
      } else {
        @Suppress("DEPRECATION")
        val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        @Suppress("DEPRECATION")
        vibrator?.vibrate(20)
      }
    } catch (_: Exception) {}
  }

  fun appendChar(str: String) {
    vibrate()
    expression += str
    // Reset momentary shift/alpha
    shiftActive = false
    alphaActive = false
    engine.isShiftActive = false
    engine.isAlphaActive = false
  }

  fun onEqualPressed() {
    vibrate()
    val trimmed = expression.trim()

    // Secret PIN check: If exact 4 digits (or entered digits) matches vault PIN
    if (trimmed.length == 4 && trimmed.all { it.isDigit() }) {
      when (val res = securityPreferences.verifyPin(trimmed)) {
        is PinVerificationResult.Success -> {
          expression = ""
          resultText = "0"
          onUnlockVault()
          return
        }
        is PinVerificationResult.LockedOut -> {
          statusMessage = "Locked out: Wait ${res.remainingSeconds}s"
          return
        }
        is PinVerificationResult.Failed -> {
          // Fall through to regular calculation so intruder has no hint!
        }
        PinVerificationResult.NotConfigured -> {
          showPinSetupDialog = true
          return
        }
      }
    }

    // Normal calculation
    if (trimmed.isEmpty()) return
    engine.angleMode = angleMode
    when (val eval = engine.evaluate(trimmed)) {
      is EvaluationResult.Success -> {
        resultText = eval.displayString
        rawResultValue = eval.rawValue
        isFractionMode = false
        coroutineScope.launch {
          historyDao.insertHistory(CalcHistoryEntity(expression = trimmed, result = eval.displayString))
        }
      }
      is EvaluationResult.Error -> {
        resultText = eval.message
      }
    }
  }

  Scaffold(
    modifier = Modifier
      .fillMaxSize()
      .testTag("calculator_screen"),
    topBar = {
      TopAppBar(
        title = {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              "CalcVault X",
              fontWeight = FontWeight.Bold,
              fontSize = 18.sp,
              color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.width(6.dp))
            Surface(
              shape = RoundedCornerShape(4.dp),
              color = MaterialTheme.colorScheme.primaryContainer,
              modifier = Modifier.padding(horizontal = 4.dp)
            ) {
              Text(
                "fx-100MS",
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onPrimaryContainer,
                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
              )
            }
          }
        },
        actions = {
          if (securityPreferences.isBiometricEnabled()) {
            IconButton(
              onClick = {
                vibrate()
                onOpenBiometric()
              },
              modifier = Modifier.testTag("biometric_btn")
            ) {
              Icon(
                imageVector = Icons.Default.Fingerprint,
                contentDescription = "Fingerprint Unlock",
                tint = MaterialTheme.colorScheme.primary
              )
            }
          }
          IconButton(
            onClick = {
              vibrate()
              showHistorySheet = true
            },
            modifier = Modifier.testTag("history_btn")
          ) {
            Icon(Icons.Default.History, contentDescription = "Calculation History")
          }
          IconButton(
            onClick = {
              vibrate()
              onOpenLauncher()
            },
            modifier = Modifier.testTag("open_launcher_btn")
          ) {
            Icon(Icons.Default.Apps, contentDescription = "Open App Launcher")
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(
          containerColor = MaterialTheme.colorScheme.background
        )
      )
    }
  ) { innerPadding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .background(MaterialTheme.colorScheme.background)
        .padding(horizontal = 12.dp, vertical = 6.dp),
      verticalArrangement = Arrangement.SpaceBetween
    ) {
      // 1. Dual-line LCD Display
      LcdDisplay(
        expression = expression,
        resultText = resultText,
        shiftActive = shiftActive,
        alphaActive = alphaActive,
        angleMode = angleMode,
        hasMemory = engine.memoryValue != 0.0,
        statusMessage = statusMessage,
        lcdTheme = lcdTheme,
        onClearStatus = { statusMessage = null }
      )

      Spacer(modifier = Modifier.height(8.dp))

      // 2. Scientific Keypad Layout (Casio fx-100MS layout)
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .weight(1f, fill = false),
        verticalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        // Navigation & Top Control Row
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          CalcButton(
            text = "SHIFT",
            subtext = null,
            color = if (shiftActive) CasioKeyShift else CasioKeyDark,
            textColor = if (shiftActive) Color.Black else CasioKeyShift,
            modifier = Modifier.weight(1f),
            testTag = "btn_shift"
          ) {
            vibrate()
            shiftActive = !shiftActive
            engine.isShiftActive = shiftActive
          }

          CalcButton(
            text = "ALPHA",
            subtext = null,
            color = if (alphaActive) CasioKeyAlpha else CasioKeyDark,
            textColor = if (alphaActive) Color.White else CasioKeyAlpha,
            modifier = Modifier.weight(1f),
            testTag = "btn_alpha"
          ) {
            vibrate()
            alphaActive = !alphaActive
            engine.isAlphaActive = alphaActive
          }

          CalcButton(
            text = "MODE",
            subtext = angleMode.name,
            color = CasioKeyDark,
            textColor = Color.White,
            modifier = Modifier.weight(1f),
            testTag = "btn_mode"
          ) {
            vibrate()
            angleMode = if (angleMode == AngleMode.DEG) AngleMode.RAD else AngleMode.DEG
            engine.angleMode = angleMode
          }

          CalcButton(
            text = "d/c",
            subtext = "a b/c",
            color = CasioKeyDark,
            textColor = Color(0xFF64D2FF),
            modifier = Modifier.weight(1f),
            testTag = "btn_frac"
          ) {
            vibrate()
            isFractionMode = !isFractionMode
            if (isFractionMode) {
              val frac = engine.toFractionString(rawResultValue)
              if (frac != null) resultText = frac
            } else {
              resultText = engine.formatResult(rawResultValue)
            }
          }
        }

        // Functions Row 1: x!, nCr, √, x², x^y, log
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          CalcButton(
            text = if (shiftActive) "x!" else "x⁻¹",
            subtext = null,
            modifier = Modifier.weight(1f)
          ) {
            appendChar(if (shiftActive) "!" else "^(-1)")
          }
          CalcButton(
            text = if (shiftActive) "³√" else "√",
            subtext = null,
            modifier = Modifier.weight(1f)
          ) {
            appendChar(if (shiftActive) "³√(" else "√(")
          }
          CalcButton(
            text = if (shiftActive) "x³" else "x²",
            subtext = null,
            modifier = Modifier.weight(1f)
          ) {
            appendChar(if (shiftActive) "³" else "²")
          }
          CalcButton(
            text = "^",
            subtext = "x^y",
            modifier = Modifier.weight(1f)
          ) {
            appendChar("^")
          }
          CalcButton(
            text = if (shiftActive) "10^x" else "log",
            subtext = null,
            modifier = Modifier.weight(1f)
          ) {
            appendChar(if (shiftActive) "10^(" else "log(")
          }
          CalcButton(
            text = if (shiftActive) "e^x" else "ln",
            subtext = null,
            modifier = Modifier.weight(1f)
          ) {
            appendChar(if (shiftActive) "exp(" else "ln(")
          }
        }

        // Trigonometric & Memory Row
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          CalcButton(
            text = "(-)",
            subtext = null,
            modifier = Modifier.weight(1f)
          ) {
            appendChar("(-")
          }
          CalcButton(
            text = if (shiftActive) "sin⁻¹" else "sin",
            subtext = null,
            modifier = Modifier.weight(1f)
          ) {
            appendChar(if (shiftActive) "asin(" else "sin(")
          }
          CalcButton(
            text = if (shiftActive) "cos⁻¹" else "cos",
            subtext = null,
            modifier = Modifier.weight(1f)
          ) {
            appendChar(if (shiftActive) "acos(" else "cos(")
          }
          CalcButton(
            text = if (shiftActive) "tan⁻¹" else "tan",
            subtext = null,
            modifier = Modifier.weight(1f)
          ) {
            appendChar(if (shiftActive) "atan(" else "tan(")
          }
          CalcButton(
            text = "(",
            subtext = null,
            modifier = Modifier.weight(1f)
          ) {
            appendChar("(")
          }
          CalcButton(
            text = ")",
            subtext = null,
            modifier = Modifier.weight(1f)
          ) {
            appendChar(")")
          }
        }

        // Row 4: 7, 8, 9, DEL, AC
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          NumberButton(text = "7", modifier = Modifier.weight(1f)) { appendChar("7") }
          NumberButton(text = "8", modifier = Modifier.weight(1f)) { appendChar("8") }
          NumberButton(text = "9", modifier = Modifier.weight(1f)) { appendChar("9") }
          CalcButton(
            text = "DEL",
            subtext = null,
            color = CasioKeyDelAc,
            textColor = Color.White,
            modifier = Modifier.weight(1f),
            testTag = "btn_del"
          ) {
            vibrate()
            if (expression.isNotEmpty()) {
              expression = expression.dropLast(1)
            }
          }
          CalcButton(
            text = "AC",
            subtext = null,
            color = CasioKeyDelAc,
            textColor = Color.White,
            modifier = Modifier.weight(1f),
            testTag = "btn_ac"
          ) {
            vibrate()
            expression = ""
            resultText = "0"
            isFractionMode = false
          }
        }

        // Row 5: 4, 5, 6, ×, ÷
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          NumberButton(text = "4", modifier = Modifier.weight(1f)) { appendChar("4") }
          NumberButton(text = "5", modifier = Modifier.weight(1f)) { appendChar("5") }
          NumberButton(text = "6", modifier = Modifier.weight(1f)) { appendChar("6") }
          CalcButton(
            text = "×",
            subtext = null,
            color = CasioKeyFunction,
            textColor = MaterialTheme.colorScheme.primary,
            modifier = Modifier.weight(1f),
            testTag = "btn_multiply"
          ) { appendChar("×") }
          CalcButton(
            text = "÷",
            subtext = null,
            color = CasioKeyFunction,
            textColor = MaterialTheme.colorScheme.primary,
            modifier = Modifier.weight(1f),
            testTag = "btn_divide"
          ) { appendChar("÷") }
        }

        // Row 6: 1, 2, 3, +, -
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          NumberButton(text = "1", modifier = Modifier.weight(1f)) { appendChar("1") }
          NumberButton(text = "2", modifier = Modifier.weight(1f)) { appendChar("2") }
          NumberButton(text = "3", modifier = Modifier.weight(1f)) { appendChar("3") }
          CalcButton(
            text = "+",
            subtext = null,
            color = CasioKeyFunction,
            textColor = MaterialTheme.colorScheme.primary,
            modifier = Modifier.weight(1f),
            testTag = "btn_plus"
          ) { appendChar("+") }
          CalcButton(
            text = "-",
            subtext = null,
            color = CasioKeyFunction,
            textColor = MaterialTheme.colorScheme.primary,
            modifier = Modifier.weight(1f),
            testTag = "btn_minus"
          ) { appendChar("-") }
        }

        // Row 7: 0, ., EXP, Ans, =
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          NumberButton(text = "0", modifier = Modifier.weight(1f)) { appendChar("0") }
          NumberButton(text = ".", modifier = Modifier.weight(1f)) { appendChar(".") }
          CalcButton(
            text = if (shiftActive) "π" else "EXP",
            subtext = null,
            color = CasioKeyNumber,
            textColor = Color.White,
            modifier = Modifier.weight(1f)
          ) {
            appendChar(if (shiftActive) "π" else "*10^")
          }
          CalcButton(
            text = if (shiftActive) "%" else "Ans",
            subtext = null,
            color = CasioKeyNumber,
            textColor = Color.White,
            modifier = Modifier.weight(1f)
          ) {
            appendChar(if (shiftActive) "%" else "Ans")
          }
          CalcButton(
            text = "=",
            subtext = null,
            color = CasioKeyEquals,
            textColor = Color.White,
            modifier = Modifier.weight(1f),
            testTag = "btn_equals"
          ) {
            onEqualPressed()
          }
        }
      }
    }
  }

  // First time PIN setup dialog
  if (showPinSetupDialog) {
    PinSetupDialog(
      onDismiss = { showPinSetupDialog = false },
      onPinCreated = { pin ->
        securityPreferences.setupPin(pin)
        showPinSetupDialog = false
        statusMessage = "PIN created! Enter '$pin' and '=' anytime to unlock vault."
      }
    )
  }

  // History Bottom Sheet
  if (showHistorySheet) {
    ModalBottomSheet(onDismissRequest = { showHistorySheet = false }) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(16.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text("Calculation History", fontWeight = FontWeight.Bold, fontSize = 18.sp)
          if (historyList.isNotEmpty()) {
            TextButton(onClick = {
              coroutineScope.launch { historyDao.clearHistory() }
            }) {
              Text("Clear All")
            }
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        if (historyList.isEmpty()) {
          Text(
            "No calculation history yet.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(vertical = 24.dp)
          )
        } else {
          historyList.take(20).forEach { item ->
            Card(
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp)
                .clickable {
                  expression = item.expression
                  resultText = item.result
                  showHistorySheet = false
                },
              colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
              Column(modifier = Modifier.padding(12.dp)) {
                Text(item.expression, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp)
                Text(
                  "= ${item.result}",
                  fontWeight = FontWeight.Bold,
                  fontSize = 16.sp,
                  color = MaterialTheme.colorScheme.primary
                )
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun LcdDisplay(
  expression: String,
  resultText: String,
  shiftActive: Boolean,
  alphaActive: Boolean,
  angleMode: AngleMode,
  hasMemory: Boolean,
  statusMessage: String?,
  lcdTheme: LcdThemeMode,
  onClearStatus: () -> Unit
) {
  Box(
    modifier = Modifier
      .fillMaxWidth()
      .height(130.dp)
      .clip(RoundedCornerShape(8.dp))
      .background(lcdTheme.bg)
      .border(2.dp, Color(0xFF1E293B), RoundedCornerShape(8.dp))
      .padding(10.dp)
      .testTag("lcd_display")
  ) {
    Column(
      modifier = Modifier.fillMaxSize(),
      verticalArrangement = Arrangement.SpaceBetween
    ) {
      // Top status annunciators
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          if (shiftActive) Text("S", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = CasioKeyShift)
          if (alphaActive) Text("A", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = CasioKeyAlpha)
          if (hasMemory) Text("M", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = lcdTheme.text)
          Text(angleMode.name, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = lcdTheme.text)
        }

        if (statusMessage != null) {
          Text(
            statusMessage,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            color = Color(0xFFB91C1C),
            modifier = Modifier.clickable { onClearStatus() }
          )
        }
      }

      // Upper Line: Expression
      val scrollState = rememberScrollState()
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .horizontalScroll(scrollState),
        horizontalArrangement = Arrangement.Start
      ) {
        Text(
          text = if (expression.isEmpty()) " " else expression,
          color = lcdTheme.text,
          fontSize = 20.sp,
          fontFamily = FontFamily.Monospace,
          letterSpacing = 1.sp,
          maxLines = 1
        )
      }

      // Lower Line: Evaluated Result
      Text(
        text = resultText,
        color = lcdTheme.text,
        fontSize = 32.sp,
        fontWeight = FontWeight.Bold,
        fontFamily = FontFamily.Monospace,
        textAlign = TextAlign.End,
        modifier = Modifier.fillMaxWidth(),
        maxLines = 1
      )
    }
  }
}

@Composable
private fun NumberButton(
  text: String,
  modifier: Modifier = Modifier,
  onClick: () -> Unit
) {
  CalcButton(
    text = text,
    subtext = null,
    color = CasioKeyNumber,
    textColor = Color.White,
    fontSize = 19.sp,
    modifier = modifier,
    testTag = "btn_num_$text",
    onClick = onClick
  )
}

@Composable
private fun CalcButton(
  text: String,
  subtext: String? = null,
  color: Color = CasioKeyDark,
  textColor: Color = Color.White,
  fontSize: androidx.compose.ui.unit.TextUnit = 14.sp,
  modifier: Modifier = Modifier,
  testTag: String = "calc_btn_${text.replace("[^a-zA-Z0-9]".toRegex(), "")}",
  onClick: () -> Unit
) {
  Surface(
    onClick = onClick,
    modifier = modifier
      .height(48.dp)
      .testTag(testTag),
    shape = RoundedCornerShape(8.dp),
    color = color,
    shadowElevation = 2.dp
  ) {
    Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
      Column(horizontalAlignment = Alignment.CenterHorizontally) {
        if (subtext != null) {
          Text(
            text = subtext,
            fontSize = 9.sp,
            color = Color(0xFF94A3B8),
            maxLines = 1
          )
        }
        Text(
          text = text,
          fontSize = fontSize,
          fontWeight = FontWeight.Bold,
          color = textColor,
          textAlign = TextAlign.Center
        )
      }
    }
  }
}

@Composable
fun PinSetupDialog(
  onDismiss: () -> Unit,
  onPinCreated: (String) -> Unit
) {
  var pin by remember { mutableStateOf("") }
  var confirmPin by remember { mutableStateOf("") }
  var errorMessage by remember { mutableStateOf<String?>(null) }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.Lock, contentDescription = null, tint = ElectricBlue)
        Spacer(modifier = Modifier.width(8.dp))
        Text("Create Secret PIN")
      }
    },
    text = {
      Column {
        Text(
          "Welcome to CalcVault X! Set your personal 4-digit PIN. Whenever you enter this PIN on the calculator and tap '=', your private vault unlocks.",
          fontSize = 13.sp,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
          value = pin,
          onValueChange = { if (it.length <= 4 && it.all { c -> c.isDigit() }) pin = it },
          label = { Text("4-Digit PIN") },
          singleLine = true,
          modifier = Modifier
            .fillMaxWidth()
            .testTag("setup_pin_input")
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
          value = confirmPin,
          onValueChange = { if (it.length <= 4 && it.all { c -> c.isDigit() }) confirmPin = it },
          label = { Text("Confirm PIN") },
          singleLine = true,
          modifier = Modifier
            .fillMaxWidth()
            .testTag("confirm_pin_input")
        )

        if (errorMessage != null) {
          Spacer(modifier = Modifier.height(8.dp))
          Text(errorMessage!!, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
        }
      }
    },
    confirmButton = {
      Button(
        onClick = {
          if (pin.length != 4) {
            errorMessage = "PIN must be exactly 4 digits"
          } else if (pin != confirmPin) {
            errorMessage = "PINs do not match"
          } else {
            onPinCreated(pin)
          }
        },
        modifier = Modifier.testTag("save_pin_btn")
      ) {
        Text("Save & Activate")
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text("Later")
      }
    }
  )
}
