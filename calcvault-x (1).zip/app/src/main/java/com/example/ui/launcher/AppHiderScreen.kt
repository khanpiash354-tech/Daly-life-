package com.example.ui.launcher

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.launcher.AppLauncherManager
import com.example.launcher.InstalledApp
import kotlinx.coroutines.launch

@Composable
fun AppHiderScreen() {
  val context = LocalContext.current
  val coroutineScope = rememberCoroutineScope()
  val launcherManager = remember { AppLauncherManager(context) }

  var installedApps by remember { mutableStateOf<List<InstalledApp>>(emptyList()) }
  var isLoading by remember { mutableStateOf(true) }
  var searchQuery by remember { mutableStateOf("") }
  var selectedTab by remember { mutableStateOf(0) } // 0: Hidden Apps, 1: All Installed Apps
  var statusMessage by remember { mutableStateOf<String?>(null) }

  fun loadApps() {
    isLoading = true
    coroutineScope.launch {
      installedApps = launcherManager.getInstalledApps(includeHidden = true)
      isLoading = false
    }
  }

  LaunchedEffect(Unit) {
    loadApps()
  }

  val hiddenApps = remember(installedApps) { installedApps.filter { it.isHidden } }
  val displayedApps = remember(installedApps, selectedTab, searchQuery) {
    val base = if (selectedTab == 0) hiddenApps else installedApps
    if (searchQuery.isBlank()) base else base.filter { it.label.contains(searchQuery, ignoreCase = true) }
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp)
      .testTag("app_hider_screen")
  ) {
    // Android isolation policy notice banner
    Card(
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
      shape = RoundedCornerShape(12.dp),
      modifier = Modifier.fillMaxWidth()
    ) {
      Row(
        modifier = Modifier.padding(12.dp),
        verticalAlignment = Alignment.Top
      ) {
        Icon(
          Icons.Default.Security,
          contentDescription = null,
          tint = MaterialTheme.colorScheme.primary,
          modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Column {
          Text(
            "Launcher-Level Privacy",
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.primary
          )
          Spacer(modifier = Modifier.height(2.dp))
          Text(
            "Apps marked as hidden here are concealed from CalcVault X's launcher and can only be launched from within this encrypted vault. System-wide isolation requires Android 15's official Private Space.",
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(12.dp))

    // Tab switcher: Hidden Apps vs All Apps
    TabRow(
      selectedTabIndex = selectedTab,
      containerColor = MaterialTheme.colorScheme.background,
      contentColor = MaterialTheme.colorScheme.primary
    ) {
      Tab(
        selected = selectedTab == 0,
        onClick = { selectedTab = 0 },
        text = { Text("Hidden in Vault (${hiddenApps.size})") }
      )
      Tab(
        selected = selectedTab == 1,
        onClick = { selectedTab = 1 },
        text = { Text("All Installed (${installedApps.size})") }
      )
    }

    Spacer(modifier = Modifier.height(10.dp))

    // Search bar
    OutlinedTextField(
      value = searchQuery,
      onValueChange = { searchQuery = it },
      placeholder = { Text("Search apps...") },
      leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
      trailingIcon = {
        if (searchQuery.isNotEmpty()) {
          IconButton(onClick = { searchQuery = "" }) {
            Icon(Icons.Default.Clear, contentDescription = "Clear")
          }
        }
      },
      singleLine = true,
      shape = RoundedCornerShape(20.dp),
      modifier = Modifier.fillMaxWidth()
    )

    Spacer(modifier = Modifier.height(8.dp))

    if (isLoading) {
      Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        CircularProgressIndicator()
      }
    } else if (displayedApps.isEmpty()) {
      Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Icon(
            imageVector = if (selectedTab == 0) Icons.Default.VisibilityOff else Icons.Default.Apps,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f),
            modifier = Modifier.size(56.dp)
          )
          Spacer(modifier = Modifier.height(12.dp))
          Text(
            if (selectedTab == 0) "No hidden apps yet" else "No apps found",
            fontSize = 15.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          if (selectedTab == 0) {
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              "Switch to 'All Installed' tab to select apps to hide.",
              fontSize = 12.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
            )
          }
        }
      }
    } else {
      LazyColumn(
        verticalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier
          .fillMaxWidth()
          .weight(1f)
      ) {
        items(displayedApps, key = { "${it.packageName}/${it.activityName}" }) { app ->
          AppItemRow(
            app = app,
            onLaunch = {
              launcherManager.launchApp(app.packageName)
            },
            onToggleHide = {
              coroutineScope.launch {
                if (app.isHidden) {
                  launcherManager.unhideApp(app.packageName, app.activityName)
                } else {
                  launcherManager.hideApp(app)
                }
                loadApps()
              }
            }
          )
        }
      }
    }
  }
}

@Composable
fun AppItemRow(
  app: InstalledApp,
  onLaunch: () -> Unit,
  onToggleHide: () -> Unit
) {
  val iconBitmap = remember(app.icon) {
    app.icon?.let { drawableToBitmap(it) }
  }

  Card(
    colors = CardDefaults.cardColors(
      containerColor = if (app.isHidden) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f) else MaterialTheme.colorScheme.surfaceVariant
    ),
    shape = RoundedCornerShape(12.dp),
    modifier = Modifier.fillMaxWidth()
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(12.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.weight(1f)
      ) {
        if (iconBitmap != null) {
          Image(
            bitmap = iconBitmap.asImageBitmap(),
            contentDescription = "${app.label} Icon",
            modifier = Modifier
              .size(44.dp)
              .clip(RoundedCornerShape(8.dp))
          )
        } else {
          Box(
            modifier = Modifier
              .size(44.dp)
              .clip(RoundedCornerShape(8.dp))
              .background(MaterialTheme.colorScheme.surface),
            contentAlignment = Alignment.Center
          ) {
            Icon(Icons.Default.Android, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
          }
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column {
          Text(
            text = app.label,
            fontWeight = FontWeight.SemiBold,
            fontSize = 15.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
          )
          Text(
            text = app.packageName,
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
          )
        }
      }

      Row(verticalAlignment = Alignment.CenterVertically) {
        // Direct launch button from within vault
        IconButton(onClick = onLaunch, modifier = Modifier.testTag("launch_${app.packageName}")) {
          Icon(Icons.Default.Launch, contentDescription = "Launch App", tint = MaterialTheme.colorScheme.primary)
        }

        // Hide / Unhide toggle
        FilledTonalIconToggleButton(
          checked = app.isHidden,
          onCheckedChange = { onToggleHide() }
        ) {
          Icon(
            imageVector = if (app.isHidden) Icons.Default.VisibilityOff else Icons.Default.Visibility,
            contentDescription = if (app.isHidden) "Unhide" else "Hide"
          )
        }
      }
    }
  }
}

fun drawableToBitmap(drawable: Drawable): Bitmap {
  if (drawable is BitmapDrawable && drawable.bitmap != null) {
    return drawable.bitmap
  }
  val width = if (drawable.intrinsicWidth > 0) drawable.intrinsicWidth else 96
  val height = if (drawable.intrinsicHeight > 0) drawable.intrinsicHeight else 96
  val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
  val canvas = Canvas(bitmap)
  drawable.setBounds(0, 0, canvas.width, canvas.height)
  drawable.draw(canvas)
  return bitmap
}
