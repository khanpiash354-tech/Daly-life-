package com.example.ui.vault

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AppDatabase
import com.example.security.SecurityPreferences
import com.example.ui.launcher.AppHiderScreen
import com.example.ui.notebook.NotebookScreen
import com.example.ui.privatespace.PrivateSpaceScreen
import com.example.ui.settings.SettingsScreen
import com.example.ui.theme.AppThemeMode

enum class VaultNavTab(val title: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
  VAULT("Vault", Icons.Default.FolderSpecial),
  NOTEBOOK("Notebook", Icons.Default.NoteAlt),
  APP_HIDER("App Hider", Icons.Default.VisibilityOff),
  PRIVATE_SPACE("Private Space", Icons.Default.Security),
  SETTINGS("Settings", Icons.Default.Settings)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VaultDashboardScreen(
  securityPreferences: SecurityPreferences,
  isDecoyMode: Boolean,
  onLockVault: () -> Unit,
  onThemeChanged: (AppThemeMode) -> Unit
) {
  val context = LocalContext.current
  val db = remember { AppDatabase.getDatabase(context) }
  var currentTab by remember { mutableStateOf(VaultNavTab.VAULT) }

  // Intercept back button to lock vault immediately for security!
  BackHandler {
    onLockVault()
  }

  Scaffold(
    modifier = Modifier
      .fillMaxSize()
      .testTag("vault_dashboard"),
    topBar = {
      TopAppBar(
        title = {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.Lock,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.primary,
              modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              "CalcVault X",
              fontWeight = FontWeight.Bold,
              fontSize = 18.sp
            )
            if (isDecoyMode) {
              Spacer(modifier = Modifier.width(6.dp))
              Surface(
                shape = RoundedCornerShape(4.dp),
                color = MaterialTheme.colorScheme.errorContainer
              ) {
                Text(
                  "DECOY",
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  color = MaterialTheme.colorScheme.onErrorContainer,
                  modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                )
              }
            }
          }
        },
        actions = {
          FilledTonalButton(
            onClick = onLockVault,
            shape = RoundedCornerShape(8.dp),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
            colors = ButtonDefaults.filledTonalButtonColors(
              containerColor = MaterialTheme.colorScheme.errorContainer,
              contentColor = MaterialTheme.colorScheme.onErrorContainer
            ),
            modifier = Modifier.testTag("lock_vault_btn")
          ) {
            Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Lock", fontSize = 12.sp, fontWeight = FontWeight.Bold)
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(
          containerColor = MaterialTheme.colorScheme.background
        )
      )
    },
    bottomBar = {
      NavigationBar(
        containerColor = MaterialTheme.colorScheme.surfaceVariant,
        tonalElevation = 8.dp
      ) {
        VaultNavTab.values().forEach { tab ->
          NavigationBarItem(
            selected = currentTab == tab,
            onClick = { currentTab = tab },
            icon = { Icon(tab.icon, contentDescription = tab.title) },
            label = { Text(tab.title, fontSize = 10.sp, maxLines = 1) },
            colors = NavigationBarItemDefaults.colors(
              selectedIconColor = MaterialTheme.colorScheme.onPrimary,
              indicatorColor = MaterialTheme.colorScheme.primary
            ),
            modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}")
          )
        }
      }
    }
  ) { innerPadding ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .background(MaterialTheme.colorScheme.background)
    ) {
      when (currentTab) {
        VaultNavTab.VAULT -> MediaVaultScreen(isDecoyMode = isDecoyMode)
        VaultNavTab.NOTEBOOK -> NotebookScreen(noteDao = db.noteDao(), isDecoyMode = isDecoyMode)
        VaultNavTab.APP_HIDER -> AppHiderScreen()
        VaultNavTab.PRIVATE_SPACE -> PrivateSpaceScreen()
        VaultNavTab.SETTINGS -> SettingsScreen(
          securityPreferences = securityPreferences,
          onThemeChanged = onThemeChanged
        )
      }
    }
  }
}
