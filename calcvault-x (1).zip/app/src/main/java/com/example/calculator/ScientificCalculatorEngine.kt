package com.example.calculator

import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale
import kotlin.math.*

enum class AngleMode {
  DEG,
  RAD
}

enum class CalcMode {
  COMP,      // Normal computation
  SD,        // Standard deviation
  REG        // Regression
}

class ScientificCalculatorEngine {
  var angleMode: AngleMode = AngleMode.DEG
  var memoryValue: Double = 0.0
  var lastAnswer: Double = 0.0
  var isShiftActive: Boolean = false
  var isAlphaActive: Boolean = false
  var calcMode: CalcMode = CalcMode.COMP

  private val decimalFormat = DecimalFormat("0.##########", DecimalFormatSymbols(Locale.US))
  private val sciFormat = DecimalFormat("0.#####E0", DecimalFormatSymbols(Locale.US))

  /**
   * Evaluates a mathematical expression string.
   * Returns a Result containing the formatted result string or error message.
   */
  fun evaluate(rawExpression: String): EvaluationResult {
    val expr = preprocessExpression(rawExpression)
    if (expr.isBlank()) return EvaluationResult.Success("0", 0.0)

    return try {
      val parser = ExpressionParser(expr, angleMode, lastAnswer, memoryValue)
      val value = parser.parse()
      if (value.isNaN()) {
        EvaluationResult.Error("Math ERROR")
      } else if (value.isInfinite()) {
        EvaluationResult.Error("Math ERROR: Division by Zero")
      } else {
        lastAnswer = value
        val formatted = formatResult(value)
        EvaluationResult.Success(formatted, value)
      }
    } catch (e: Exception) {
      EvaluationResult.Error(e.message ?: "Syntax ERROR")
    }
  }

  fun formatResult(value: Double): String {
    if (abs(value) < 1e-11 && abs(value) > 0) return "0"
    if (abs(value) >= 1e11 || (abs(value) > 0 && abs(value) < 1e-5)) {
      return sciFormat.format(value).replace("E", "×10^")
    }
    return decimalFormat.format(value)
  }

  fun toFractionString(value: Double): String? {
    if (value.isNaN() || value.isInfinite()) return null
    val tolerance = 1.0E-6
    var h1 = 1L
    var h2 = 0L
    var k1 = 0L
    var k2 = 1L
    var b = value
    do {
      val a = floor(b).toLong()
      var aux = h1
      h1 = a * h1 + h2
      h2 = aux
      aux = k1
      k1 = a * k1 + k2
      k2 = aux
      b = 1.0 / (b - a)
    } while (abs(value - h1.toDouble() / k1.toDouble()) > value * tolerance && k1 < 100000L)

    if (k1 <= 1L || k1 > 100000L) return null
    val whole = h1 / k1
    val remainder = abs(h1 % k1)
    return if (whole != 0L && remainder != 0L) {
      "$whole ⌟ $remainder/$k1"
    } else {
      "$h1/$k1"
    }
  }

  private fun preprocessExpression(expr: String): String {
    return expr
      .replace("×", "*")
      .replace("÷", "/")
      .replace("π", "${Math.PI}")
      .replace("Ans", "$lastAnswer")
      .replace("e", "${Math.E}")
  }
}

sealed class EvaluationResult {
  data class Success(val displayString: String, val rawValue: Double) : EvaluationResult()
  data class Error(val message: String) : EvaluationResult()
}

/**
 * Recursive descent parser for scientific expressions
 */
private class ExpressionParser(
  private val input: String,
  private val angleMode: AngleMode,
  private val ans: Double,
  private val mem: Double
) {
  private var pos = -1
  private var ch = 0

  private fun nextChar() {
    pos++
    ch = if (pos < input.length) input[pos].code else -1
  }

  private fun eat(charToEat: Int): Boolean {
    while (ch == ' '.code) nextChar()
    if (ch == charToEat) {
      nextChar()
      return true
    }
    return false
  }

  fun parse(): Double {
    nextChar()
    val x = parseExpression()
    while (ch == ' '.code) nextChar()
    if (pos < input.length) throw IllegalArgumentException("Syntax ERROR at '${input[pos]}'")
    return x
  }

  private fun parseExpression(): Double {
    var x = parseTerm()
    while (true) {
      when {
        eat('+'.code) -> x += parseTerm()
        eat('-'.code) -> x -= parseTerm()
        else -> return x
      }
    }
  }

  private fun parseTerm(): Double {
    var x = parseFactor()
    while (true) {
      when {
        eat('*'.code) -> x *= parseFactor()
        eat('/'.code) -> {
          val denom = parseFactor()
          if (denom == 0.0) throw ArithmeticException("Division by zero")
          x /= denom
        }
        eat('%'.code) -> x = (x * parseFactor()) / 100.0
        else -> return x
      }
    }
  }

  private fun parseFactor(): Double {
    if (eat('+'.code)) return +parseFactor()
    if (eat('-'.code)) return -parseFactor()

    var x: Double
    val startPos = pos
    if (eat('('.code)) {
      x = parseExpression()
      if (!eat(')'.code)) throw IllegalArgumentException("Missing closing parenthesis ')'")
    } else if ((ch in '0'.code..'9'.code) || ch == '.'.code) {
      while ((ch in '0'.code..'9'.code) || ch == '.'.code) nextChar()
      x = input.substring(startPos, pos).toDouble()
    } else if (ch in 'a'.code..'z'.code || ch in 'A'.code..'Z'.code || ch == '√'.code || ch == '³'.code) {
      while (ch in 'a'.code..'z'.code || ch in 'A'.code..'Z'.code || ch in '0'.code..'9'.code || ch == '√'.code || ch == '³'.code || ch == '⁻'.code || ch == '¹'.code) nextChar()
      val func = input.substring(startPos, pos)
      if (eat('('.code)) {
        val arg = parseExpression()
        if (!eat(')'.code)) throw IllegalArgumentException("Missing ')' after $func")
        x = applyFunction(func, arg)
      } else {
        // Unary function without explicit parentheses (e.g. √9 or sin30)
        val arg = parseFactor()
        x = applyFunction(func, arg)
      }
    } else {
      throw IllegalArgumentException("Unexpected character '${if (ch != -1) ch.toChar().toString() else "end"}'")
    }

    // Postfix operators: powers (^), factorial (!), inverse (⁻¹), square (²), cube (³)
    while (true) {
      when {
        eat('^'.code) -> {
          val exponent = parseFactor()
          x = x.pow(exponent)
        }
        eat('!'.code) -> {
          if (x < 0 || x != floor(x)) throw IllegalArgumentException("Factorial requires non-negative integer")
          x = factorial(x.toLong()).toDouble()
        }
        eat('²'.code) -> x = x * x
        eat('³'.code) -> x = x * x * x
        else -> return x
      }
    }
  }

  private fun applyFunction(func: String, arg: Double): Double {
    return when (func.lowercase(Locale.ROOT)) {
      "sqrt", "√" -> if (arg < 0) Double.NaN else sqrt(arg)
      "cbrt", "³√" -> cbrt(arg)
      "sin" -> sin(if (angleMode == AngleMode.DEG) Math.toRadians(arg) else arg)
      "cos" -> cos(if (angleMode == AngleMode.DEG) Math.toRadians(arg) else arg)
      "tan" -> {
        val rad = if (angleMode == AngleMode.DEG) Math.toRadians(arg) else arg
        if (abs(cos(rad)) < 1e-15) Double.NaN else tan(rad)
      }
      "asin", "sin⁻¹" -> {
        val res = asin(arg)
        if (angleMode == AngleMode.DEG) Math.toDegrees(res) else res
      }
      "acos", "cos⁻¹" -> {
        val res = acos(arg)
        if (angleMode == AngleMode.DEG) Math.toDegrees(res) else res
      }
      "atan", "tan⁻¹" -> {
        val res = atan(arg)
        if (angleMode == AngleMode.DEG) Math.toDegrees(res) else res
      }
      "log" -> if (arg <= 0) Double.NaN else log10(arg)
      "ln" -> if (arg <= 0) Double.NaN else ln(arg)
      "exp", "e^" -> exp(arg)
      "10^" -> 10.0.pow(arg)
      "abs" -> abs(arg)
      "reciprocal", "inv" -> if (arg == 0.0) Double.POSITIVE_INFINITY else 1.0 / arg
      else -> throw IllegalArgumentException("Unknown function '$func'")
    }
  }

  private fun factorial(n: Long): Long {
    if (n > 20) throw ArithmeticException("Overflow: Factorial > 20!")
    var result = 1L
    for (i in 2..n) result *= i
    return result
  }
}
