package com.example.privatespace

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.UserManager
import android.provider.Settings

data class PrivateSpaceStatus(
  val isAndroid15OrHigher: Boolean,
  val isSupportedByDevice: Boolean,
  val statusDescription: String,
  val recommendation: String
)

object PrivateSpaceManager {
  private const val ACTION_PRIVATE_SPACE_SETTINGS = "android.settings.PRIVATE_SPACE_SETTINGS"

  fun checkSupport(context: Context): PrivateSpaceStatus {
    val isApi35 = Build.VERSION.SDK_INT >= 35

    if (!isApi35) {
      return PrivateSpaceStatus(
        isAndroid15OrHigher = false,
        isSupportedByDevice = false,
        statusDescription = "Android 15+ is required for OS-level Private Space (Current device: Android ${Build.VERSION.RELEASE}, API ${Build.VERSION.SDK_INT}).",
        recommendation = "CalcVault X provides an on-device AES-256 encrypted vault and app hider launcher that works completely offline on all Android versions."
      )
    }

    // Android 15+ check
    val userManager = context.getSystemService(Context.USER_SERVICE) as? UserManager
    val intent = Intent(ACTION_PRIVATE_SPACE_SETTINGS)
    val canResolveSettings = intent.resolveActivity(context.packageManager) != null

    return if (canResolveSettings) {
      PrivateSpaceStatus(
        isAndroid15OrHigher = true,
        isSupportedByDevice = true,
        statusDescription = "Android Private Space is available on this device! You can create a system-isolated private profile.",
        recommendation = "Tap below to configure official Android Private Space settings or use CalcVault X's built-in secure vault."
      )
    } else {
      PrivateSpaceStatus(
        isAndroid15OrHigher = true,
        isSupportedByDevice = false,
        statusDescription = "Device runs Android 15+, but the manufacturer has disabled or modified the system Private Space profile.",
        recommendation = "CalcVault X's hardware-backed AES-256 vault and launcher hider is active and protecting your files and apps."
      )
    }
  }

  fun openSystemPrivateSpaceSettings(context: Context): Boolean {
    return try {
      val intent = Intent(ACTION_PRIVATE_SPACE_SETTINGS).apply {
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      }
      if (intent.resolveActivity(context.packageManager) != null) {
        context.startActivity(intent)
        true
      } else {
        // Fallback to general security settings
        val securityIntent = Intent(Settings.ACTION_SECURITY_SETTINGS).apply {
          addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(securityIntent)
        true
      }
    } catch (_: Exception) {
      false
    }
  }
}
